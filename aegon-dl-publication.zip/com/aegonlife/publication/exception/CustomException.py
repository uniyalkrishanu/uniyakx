class ErrorException(Exception):
    def __init__(self, errorCode, errorMessage, errorPayload):
        self.errorCode = errorCode
        self.errorMessage = errorMessage
        self.errorPayload = errorPayload


class FileConfigurationNotFound(ErrorException):
    def __init__(self, errorPayload):
        super().__init__('101', 'Processor Configuration not found', errorPayload)

class FailedToReadFile(ErrorException):
    def __init__(self, errorPayload):
        super().__init__('102', 'Error while reading input file', errorPayload)
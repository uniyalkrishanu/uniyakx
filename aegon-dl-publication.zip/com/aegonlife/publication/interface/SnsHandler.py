import logging
import traceback


class SnsHandler(object):
    def __init__(self, event, context):
        """SNS Handler: To read event triggered through SNS handler and read input arguments"""
        self.event = event
        self.context = context
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel('INFO')

    def sns_handler(self):
        try:
            config_key = self.event['file_control_nm']
            file_to_be_processed = self.event['staging_file_key']
            file_meta_data_key = self.event['file_name']
            batch_id = self.event['batch_id']
            return config_key, file_to_be_processed, file_meta_data_key, batch_id
        except Exception as e:
            self.logger.error(traceback.format_exc())

from __future__ import print_function
import json
import traceback
import logging
import sys
from .SnsHandler import SnsHandler
from ..core.PublicationFlow import PublicationFlow
from ..exception.CustomException import *

logger = logging.getLogger(__name__)
logger.setLevel('INFO')


def FileProcessingHandler(event, context):
    logger.info('*************** Publication Processor Lambda execution started ***************')
    try:
        if 'Records' in event:
            for record in event['Records']:
                if 'sns' in record:
                    handler_obj = SnsHandler(event['Records']['sns'], context)
                    config_key, fileToBeProcessed, file_meta_data_key, batch_id = handler_obj.sns_handler()
                    publication_flow_obj = PublicationFlow(config_key, fileToBeProcessed, file_meta_data_key, batch_id)
                    publication_flow_obj.publication_processor()
                if 'Message' in record:
                    df_dict = {}
                    for item in event['Records']['Message']:
                        handler_obj = SnsHandler(item, context)
                        config_key, fileToBeProcessed, file_meta_data_key, batch_id = handler_obj.sns_handler()
                        publication_flow_obj = PublicationFlow(config_key, fileToBeProcessed, file_meta_data_key,
                                                               batch_id, df_dict)
                        publication_flow_obj.publication_processor()
        else:
            if 'Message' in event:
                df_dict = {}
                event1 = json.loads(event['Message'])
                handler_obj = SnsHandler(event1, context)
                config_key, fileToBeProcessed, file_meta_data_key, batch_id = handler_obj.sns_handler()
                publication_flow_obj = PublicationFlow(config_key, fileToBeProcessed, file_meta_data_key, batch_id,
                                                       df_dict)
                publication_flow_obj.publication_processor()


    except FileConfigurationNotFound as e:
        response = {'exception': 'FileConfigurationNotFound', 'errorCode': e.errorCode, 'errorMessage': e.errorMessage,
                    'errorPayload': e.errorPayload}
        logger.error(response)

    except FailedToReadFile as e:
        response = {'exception': 'FailedToReadFile', 'errorCode': e.errorCode, 'errorMessage': e.errorMessage,
                    'errorPayload': e.errorPayload}
        logger.error(response)

    except Exception as e:
        logger.error("Unexpected error at generic handler:{}".format(sys.exc_info()[0]))
        logger.error(traceback.format_exc())
        return ({
            'statusCode': 400,
            'body': json.dumps(
                'error in executing Publication Processor Lambda with error:{}' + format(sys.exc_info()[0]))
        })

import boto3
import pandas as pd
import pyarrow.parquet as pq
import logging
import traceback
import s3fs
import fsspec

class S3Reader:

    def __init__(self, file_to_be_processed, config_item):
        """S3 Reader: Parent class to different s3 file format readers"""
        self.df = None
        self.file_to_be_processed = file_to_be_processed
        self.config_item = config_item
        self.s3 = boto3.resource('s3', region_name="ap-south-1")
        self.logger = logging.getLogger()
        self.logger.setLevel('INFO')
        self.input_bucket = self.config_item.inputBucket
        self.unique_key = self.config_item.uniqueKey.split(',')
        self.staging_input_schema = self.config_item.mapping.values()
        self.input_file_delimiter = self.config_item.delimiter


class s3_parquet_reader(S3Reader):
    def __init__(self, file_to_be_processed, config_item):
        super().__init__(file_to_be_processed, config_item)

    def read_file(self):
        try:
            file_to_be_processed = 's3://' + self.input_bucket + '/' + self.file_to_be_processed
            self.df = pq.read_table(file_to_be_processed).to_pandas()
            # TODO not required to drop duplicates
            self.df = self.df.drop_duplicates(subset=self.unique_key, keep="last")
            self.df = self.df.fillna('')
            return self.df

        except Exception as e:
            self.logger.error("Unable to read from s3 file" + traceback.format_exc())



class s3_csv_reader(S3Reader):

    def __init__(self, file_to_be_processed, config_item):
        super().__init__(file_to_be_processed, config_item)

    def read_file(self):
        try:
            # reading S3 object
            obj = self.s3.Object(self.input_bucket, self.file_to_be_processed)
            response_file = obj.get()['Body']._raw_stream
            self.df = pd.read_csv(response_file, sep=self.input_file_delimiter)
            self.df = self.df.fillna('')
            return self.df

        except Exception as e:
            self.logger.warning("Unable to read from s3 file" + traceback.format_exc())


class s3_dat_reader(S3Reader):

    def __init__(self, file_to_be_processed, config_item):
        super().__init__(file_to_be_processed, config_item)

    def read_file(self):
        try:

            file_to_be_processed = 's3://' + self.input_bucket + '/' + self.file_to_be_processed
            print('file_to_be_processed', file_to_be_processed)
            self.df = pd.read_csv(file_to_be_processed,
                                  sep='\~\|\~',
                                  encoding='mac_roman',
                                  dtype="str",
                                  engine='python',
                                  skipfooter=1).fillna('')
            # self.df = pd.read_table(response_file, sep=self.input_file_delimiter, engine='python', skipfooter=1)
            self.df = self.df.drop_duplicates(subset=self.unique_key, keep="last")
            self.df = self.df.fillna('')
            return self.df
        except Exception as e:
            self.logger.warning("Unable to read from s3 file" + traceback.format_exc())

from com.aegonlife.publication.core.reader.S3Reader import *

class ReaderFactory:
    @staticmethod
    def get_s3_reader(file_format, file_to_be_processed, config_item):
        if file_format == 'parquet':
            return s3_parquet_reader(file_to_be_processed, config_item)
        elif file_format == 'csv':
            return s3_csv_reader(file_to_be_processed, config_item)
        elif file_format == 'dat':
            return s3_dat_reader(file_to_be_processed, config_item)

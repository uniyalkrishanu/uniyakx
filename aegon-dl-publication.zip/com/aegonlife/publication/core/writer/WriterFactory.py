from com.aegonlife.publication.core.writer.TargetWriter import *
import logging

logger = logging.getLogger(__name__)
logger.setLevel('INFO')

class WriterFactory:
    @staticmethod
    def write_to_target(output_writer, config_item, df):
        
        if 's3' in output_writer:
            return S3CsvWriter(config_item, df)
        elif 'postgre' in output_writer:
            return PostgreWriter(config_item, df)
        elif 'dynamodb' in output_writer:
            return DynamoWriter(config_item, df)

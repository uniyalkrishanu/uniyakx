import psycopg2
import psycopg2.extras as extras
import os
import boto3
import logging
import traceback
import sys
import json
from io import StringIO
from datetime import datetime
from dateutil.tz import gettz
from decimal import Decimal
from pytz import timezone
from aegon_datalake_common.config_module.configProvider.processor import Processor
from ...interface.SnsHandler import SnsHandler

class TargetWriter:
    def __init__(self, config_item: Processor, df):
        self.s3 = boto3.resource('s3', region_name="ap-south-1")
        self.ssm = boto3.client('ssm')
        self.dynamodb = boto3.resource('dynamodb')
        self.config_item = config_item
        self.df = df.fillna('')
        self.output = self.config_item.outputs.output
        self.output_bucket = None  # self.config_item.outputBucket
        self.output_path = None  # self.config_item.outputPath
        self.schema = None  # self.config_item.schema
        self.table = None  # config_item.table
        self.system = self.config_item.system
        self.file = self.config_item.file
        self.db_unique_key = None
        self.active_record_unique_key = None
        self.partition_key = None
        self.partition_key_name = None
        self.sort_key = None
        self.batch_metadata_params_namespace = '	/config/aegon_fatp/batch_metadata.dbconfig'  # os.environ['batch_metadata_params_namespace']
        self.conn = None
        self.cursor = None
        self.output_response = {}
        self.host = self.ssm.get_parameter(Name=self.batch_metadata_params_namespace + '.host')['Parameter']['Value']
        self.user = self.ssm.get_parameter(Name=self.batch_metadata_params_namespace + '.user')['Parameter']['Value']
        self.password = self.ssm.get_parameter(Name=self.batch_metadata_params_namespace + '.password')['Parameter'][
            'Value']
        self.database = self.ssm.get_parameter(Name=self.batch_metadata_params_namespace + '.dbname')['Parameter'][
            'Value']
        self.date_time = datetime.now().strftime("%Y%m%d%H%M%S")
        self.logger = logging.getLogger()
        self.logger.setLevel('INFO')


class S3CsvWriter(TargetWriter):
    """S3 CSV Writer: To write processed file to S3 bucket, CSV format"""

    def __init__(self, config_item: Processor, df):
        super().__init__(config_item, df)

    def write_df(self, file_meta_data_key):
        try:
            for output_item in self.output:
                if 's3' in output_item.outputWriter:
                    # adding date for s3 key
                    self.output_response['writer'] = 's3'
                    self.output_bucket = output_item.outputBucket
                    # self.output_path = output_item.outputPath + self.date_time + ".csv"
                    self.output_path = output_item.outputPath + "/" + "year=" + str(
                        datetime.now(timezone('Asia/Kolkata')).year).zfill(
                        2) + "/" + "month=" + str(datetime.now(timezone('Asia/Kolkata')).month).zfill(
                        2) + "/" + "day=" + str(
                        datetime.now(timezone('Asia/Kolkata')).day).zfill(2) + "/" + "hour=" + str(
                        datetime.now(timezone('Asia/Kolkata')).hour).zfill(
                        2) + "/" + self.system + "_" + self.file + ".csv"

            # writing json to s3
            csv_buffer = StringIO()
            self.df.to_csv(csv_buffer, header=True, sep=',', index=False)
            response = self.s3.Object(self.output_bucket, self.output_path).put(Body=csv_buffer.getvalue())
            if response['ResponseMetadata']['HTTPStatusCode'] == 200:
                self.logger.info("Data successfully written to S3 {}/{}".format(self.output_bucket, self.output_path))
                self.output_response['status'] = 'SUCCESS'
            return self.output_response
        except Exception as e:
            self.logger.warning("Unable to write to s3 " + traceback.format_exc())
            self.output_response['status'] = 'FAILED'
            return self.output_response


class PostgreWriter(TargetWriter):
    """Postgre Writer: To push processed file in psql table"""

    def __init__(self, config_item, df):
        super().__init__(config_item, df)

    def update_end_date(self, file_meta_data_key):
        curr_date_time = str(datetime.now(tz=gettz('Asia/Kolkata')).strftime("%Y/%m/%d, %H:%M:%S")).replace(',', '')
        tuple_update_check = [tuple(self.df[self.active_record_unique_key])]
        update_query = "Update %s set end_date = '%s' where %s in %%s" % (
        self.table, curr_date_time, self.active_record_unique_key)
        results = extras.execute_values(self.cursor, update_query, tuple_update_check)
        self.conn.commit()

    def truncate_table(self):
        truncate_table = "TRUNCATE TABLE %s" % self.table
        self.cursor.execute(truncate_table)
        self.conn.commit()

    def truncate_source_system(self):
        truncate_source_system = "DELETE FROM %s where source_system = '%s'" % (self.table, self.system)
        self.cursor.execute(truncate_source_system)
        self.conn.commit()

    def insert_to_table(self):
        # insert data in current process
        placeholder = ""
        for col in self.df.columns:
            placeholder = placeholder + "," + col + " = EXCLUDED." + col

        # To validate entries before insertion
        record_count = self.get_record_count()
        self.logger.info('Count before insertion in table {}, is {}'.format(self.table, record_count))

        tuples = [tuple(x) for x in self.df.to_numpy()]
        cols = ','.join(list(self.df.columns))
        db_unique_key = ', '.join(item for item in self.db_unique_key)
        query = "INSERT INTO %s(%s) VALUES %%s ON CONFLICT (%s) DO UPDATE SET %s" % (
        self.table, cols, db_unique_key, placeholder[1:])
        results = extras.execute_values(self.cursor, query, tuples)
        self.conn.commit()

        # To validate entries after insertion
        record_count = self.get_record_count()
        self.logger.info('Count after insertion in table {}, is {}'.format(self.table, record_count))

        return results

    def write_df(self, file_meta_data_key):
        try:
            result = {}
            self.conn = self.get_connection()
            # conn.autocommit = True
            self.cursor = self.conn.cursor()
            for output_item in self.output:
                if 'postgre' in output_item.outputWriter:
                    self.schema = output_item.schema
                    self.table = self.schema + '.' + output_item.table
                    self.active_record_unique_key = output_item.activeRecordUniqueKey
                    self.db_unique_key = output_item.dbUniqueKey.split(',')

            # update end_date for historical data
            if self.system in ['FFA', 'HPMS']:
                if self.config_item.file == 'aged_suspense':
                    self.truncate_source_system()
                if self.config_item.file in ['activity', 'breakdown']:
                    self.truncate_table()
            if self.system == 'HM':
                if self.file == 'aged_suspense':
                    self.update_end_date()

            self.insert_to_table()

            if self.cursor:
                self.cursor.close()
            if self.conn:
                self.conn.close()

            result["status"] = "success"
            return result
            # create_table = "CREATE TABLE finance_db.FFA_FINANCE_SUSPENSE_DAILY (suspense_account_type VARCHAR(255),cash_batch_id VARCHAR(255),payment_mode VARCHAR(255),applied_date VARCHAR(255),deposit_date VARCHAR(255),creation_date VARCHAR(255),name_of_customer VARCHAR(255),client_id VARCHAR(255),contract_no VARCHAR(255),modal_premium VARCHAR(255),amount VARCHAR(255),chq_dd_types VARCHAR(255),cheque_status VARCHAR(255),date_of_last_transaction_in_the_contract VARCHAR(255),no_of_days_pending VARCHAR(255),reason VARCHAR(255),branch_name VARCHAR(255),zone_name VARCHAR(255),next_modal_prem VARCHAR(255),billing_mode VARCHAR(255),paid_to_date VARCHAR(255),status VARCHAR(255),status_reason VARCHAR(255),batch_id VARCHAR(255),insert_timestamp  VARCHAR(255), end_date VARCHAR(255), suspense_account_type_new VARCHAR(255), reason_new VARCHAR(255), PRIMARY KEY(contract_no,suspense_account_type_new,reason_new))"
            # self.cursor.execute(create_table)
            # self.conn.commit()

        except:
            self.logger.warning("Failed to write data in PSql " + traceback.format_exc())
            self.cursor.close()
            self.conn.close()

    def get_connection(self):
        try:
            self.conn = psycopg2.connect(
                "dbname={} user={} host={} password={}".format(self.database, self.user, self.host, self.password))
            return self.conn
        except:
            self.logger.error("Failed to get Connection:{}".format(sys.exc_info()[0]))
            self.logger.error(traceback.format_exc())

    def get_record_count(self):
        self.cursor.execute("select count(*) from %s" % self.table)
        results = self.cursor.fetchone()
        return str(results[0])


class DynamoWriter(TargetWriter):
    def __init__(self, config_item, df):
        super().__init__(config_item, df)

    def write_df(self, file_meta_data_key):
        try:
            for output_item in self.output:
                if 'dynamodb' in output_item.outputWriter:
                    self.output_response['writer'] = 'dynamodb'
                    self.table = output_item.table
                    self.partition_key = output_item.partitionKey.split(',')
                    self.partition_key_name = output_item.PartitionKeyName
                    self.sort_key = output_item.sortKey.split(',')

            self.df = self.get_partition_sort_keys(file_meta_data_key)
            dynamo_table = self.dynamodb.Table(self.table)
            with dynamo_table.batch_writer() as batch:
                for index, row in self.df.iterrows():
                    batch.put_item(json.loads(row.to_json(), parse_float=Decimal))

            print(dynamo_table.item_count)
            self.output_response['status'] = 'SUCCESS'
            return self.output_response

        except Exception as e:
            self.logger.warning("Unable to write to dynamodb " + traceback.format_exc())
            self.output_response['status'] = 'FAILED'
            return self.output_response

    def get_partition_sort_keys(self, file_meta_data_key):
        #self.df[self.partition_key_name] = ''
        #self.df[self.sort_key] = str(datetime.now(tz=gettz('Asia/Kolkata')).strftime("%Y/%m/%d, %H:%M:%S")).replace(',',
        #                                                                                                                '')
        created_at = '20'+file_meta_data_key[file_meta_data_key.rindex('_')+1:file_meta_data_key.index('.')]
        self.df[self.sort_key] = datetime.strptime(created_at, '%Y%m%d%H%M%S').strftime('%Y/%m/%d')

        self.df[self.partition_key_name] = self.df[self.partition_key].apply(lambda x: '_'.join(x), axis=1)
        # self.df[self.sort_key] = self.df[self.sort_key].apply(lambda x: '_'.join(x), axis=1)
        return self.df

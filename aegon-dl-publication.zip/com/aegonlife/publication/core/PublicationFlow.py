import logging

from com.aegonlife.publication.core.config.ConfigProvider import DynamoDbReader
from com.aegonlife.publication.core.handler.agedsuspense.AgedSuspenseHandler import *
from .handler.ffa.ofi.FFAFinanceHandler import *
from .handler.ods.policymaster.PolicyMasterHandler import *
from .handler.ods.coverage.CoverageBuilder import *
from .handler.ods.addclientinfo.AddClientInfoHandler import *
from .handler.ods.address.AddressHandler import *
from .handler.ods.prpdep.PrpdepHandler import *
from .handler.ods.nominee.NomineeHandler import *
from com.aegonlife.publication.exception.CustomException import FileConfigurationNotFound


class PublicationFlow:

    def __init__(self, config_key, file_to_be_processed, file_meta_data_key, batch_id, df_dict):
        self.config_key = config_key
        self.file_to_be_processed = file_to_be_processed
        self.file_meta_data_key = file_meta_data_key
        self.batch_id = batch_id
        self.logger = logging.getLogger()
        self.logger.setLevel('INFO')
        self.df_dict = df_dict

    def publication_processor(self):

        config_item = DynamoDbReader(self.config_key).dynamo_config_reader()
        if config_item is not None:
            system = config_item.system
            file = config_item.file

            #test process for job metadatalogger
            #JobMetadataLogger(file, self.batch_id).log_event()

            if system == 'FFA':
                if file in ['activity', 'breakdown']:
                    FinanceBuilder(self.df_dict, config_item, self.config_key, self.file_to_be_processed, self.file_meta_data_key).process_event()
            if system == 'ODS':
                if file == 'policy_master':
                    PolicyMasterBuilder(self.config_key, self.file_to_be_processed, config_item, self.file_meta_data_key).process_event()
                if file == 'coverage':
                    CoverageBuilder(self.config_key, self.file_to_be_processed, config_item, self.file_meta_data_key).process_event()
                if file == 'add_client_info':
                    AddClientInfoHandler(self.config_key, self.file_to_be_processed, config_item, self.file_meta_data_key).process_event()
                if file == 'address':
                    AddressHandler(self.config_key, self.file_to_be_processed, config_item, self.file_meta_data_key).process_event()
                if file == 'nominee':
                    NomineeHandler(self.config_key, self.file_to_be_processed, config_item, self.file_meta_data_key).process_event()
                if file == 'prpdep':
                    PrpdepHandler(self.config_key, self.file_to_be_processed, config_item, self.file_meta_data_key).process_event()
            if system in ['FFA', 'HPMS']:
                if file == 'aged_suspense':
                    AgedSuspenseHandler(self.file_to_be_processed, config_item, self.file_meta_data_key).process_event()

        else:
            raise (FileConfigurationNotFound(dict(fileName=self.file_meta_data_key, configKey=self.config_key)))

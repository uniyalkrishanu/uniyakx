class Activity:
    def __init__(self, row):
        """To get activity attributes as objects"""
        self.activity = None
        self.row = row
        self.breakdown_item = None
        self.breakdown_typecasted = []

    @property
    def CURRENCY_CODE(self):
        return str(self.row.get('CURRENCY'))

    @property
    def FINANCIAL_ACTIVITY_CLASS(self):
        return str(self.row.get('FINANCIAL_ACTIVITY_CLASS'))

    @property
    def FINANCIAL_ACTIVITY_IDENTIFIER(self):
        return str(self.row.get('FINANCIAL_ACTIVITY_IDENTIFIER'))

    @property
    def EFFECTIVE_DATE_OF_TRANSACTION(self):
        return str(self.row.get("PROCESSED_DATE_TIME"))

    @property
    def JOURNAL_CATEGORY(self):
        return str(self.row.get('FINANCIAL_ACTIVITY_CLASS'))

    @property
    def AMOUNT(self):
        return str(self.row.get('AMOUNT'))

    @property
    def JOURNAL_ENTRY_CREATION_DATE(self):
        return str(self.row.get('PROCESSED_DATE_TIME'))

    @property
    def ENTERED_CREDIT_AMOUNT(self):
        return str(self.row.get('DEBIT_CREDIT'))

    @property
    def ENTERED_DEBIT_AMOUNT(self):
        return str(self.row.get('DEBIT_CREDIT'))

    @property
    def SEGMENT5(self):
        return str(self.row.get('CHANNEL_CODE'))

    @property
    def SEGMENT7(self):
        return str(self.row.get('Product_Identifier'))

    @property
    def TRANSACTION_BRANCH(self):
        return str(self.row.get('TRANSACTION_BRANCH'))

    @property
    def CONTRACT_ID(self):
        return str(self.row.get('CONTRACT_ID'))

    @property
    def CONTRACT_BILLING_FREQUENCY(self):
        return str(self.row.get('CONTRACT_BILLING_FREQUENCY'))

    @property
    def CONTRACT_EFFECTIVE_DATE(self):
        return str(self.row.get("CONTRACT_EFFECTIVE_DATE date 'dd/mm/rrrr'"))

    @property
    def PRODUCT_TYPE(self):
        return str(self.row.get('PRODUCT_TYPE'))

    @property
    def ATTRIBUTE1_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF(self):
        return str(self.row.get('CONTRACT_ID'))

    @property
    def ATTRIBUTE2_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF(self):
        return str(self.row.get('PAYMENT_MODE'))

    @property
    def ATTRIBUTE3_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF(self):
        return str(self.row.get('RURAL_INDICATOR'))

    @property
    def ATTRIBUTE32_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF(self):
        return str(self.row.get('REINSURANCE_INDICATOR'))

    @property
    def ATTRIBUTE33_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF(self):
        return str(self.row.get('CASH_BATCH_ID'))

    @property
    def ATTRIBUTE36_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF(self):
        return str(self.row.get('Product_Identifier'))

    @property
    def SUSPENSE_ACCOUNT_TYPE(self):
        return str(self.row.get('SUSPENSE_ACCOUNT_TYPE'))

    @property
    def PREMIUM_TYPE(self):
        return str(self.row.get('PREMIUM_TYPE'))

    @property
    def SURRENDER_TYPE(self):
        return str(self.row.get('SURRENDER_TYPE'))

    @property
    def CASH_BATCH_ID(self):
        return str(self.row.get('CASH_BATCH_ID'))

    @property
    def ATTRIBUTE4_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF(self):
        return str(self.row.get('TRANSACTION_BRANCH'))

    @property
    def ATTRIBUTE5_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF(self):
        return str(self.row.get('CASH_TYPE'))

    @property
    def ATTRIBUTE8_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF(self):
        return str(self.row.get('CASH_BATCH_ID'))

    @property
    def PAYMENT_INVOICE_NUMBER(self):
        return str(self.row.get('FINANCIAL_ACTIVITY_IDENTIFIER'))

    @property
    def CLAIM_TYPE(self):
        return str(self.row.get('CLAIM_TYPE'))

    @property
    def PRODUCT_CATEGORY(self):
        return str(self.row.get('Product_Category'))

    @property
    def PRODUCT_IDENTIFIER(self):
        return str(self.row.get('Product_Identifier'))

    @property
    def BREAKDOWN(self):
        self.breakdown_item = self.row.get('BREAKDOWN')
        if self.breakdown_item is not None:
            for item in range(len(self.breakdown_item)):
                self.breakdown_typecasted.append({key: str(value) for key, value in self.breakdown_item[item].items()})
        return self.breakdown_typecasted

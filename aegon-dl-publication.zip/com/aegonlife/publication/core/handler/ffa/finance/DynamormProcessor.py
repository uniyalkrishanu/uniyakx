from com.aegonlife.publication.core.handler.ffa.finance.domain.Activity import Activity
from dynamorm import DynaModel
from marshmallow import fields


class DynamormProcessor:

    def __init__(self):
        """Dynamorm handler for FFA Activity and Breakdown"""
        self.df_dict = None
        self.df = self.get_activity_breakdown_df()

    def write_to_dynamo(self):
        list_of_items = []
        for index, row in self.df.iterrows():
            activity = Activity(row)

            list_of_items.append({"CURRENCY_CODE": activity.CURRENCY_CODE,
                                  "EFFECTIVE_DATE_OF_TRANSACTION": activity.EFFECTIVE_DATE_OF_TRANSACTION,
                                  "JOURNAL_CATEGORY": activity.JOURNAL_CATEGORY,
                                  "JOURNAL_ENTRY_CREATION_DATE": activity.JOURNAL_ENTRY_CREATION_DATE,
                                  "AMOUNT": activity.AMOUNT,
                                  "ATTRIBUTE1_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF": activity.ATTRIBUTE1_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF,
                                  "ATTRIBUTE2_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF": activity.ATTRIBUTE2_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF,
                                  "ATTRIBUTE3_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF": activity.ATTRIBUTE3_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF,
                                  "ATTRIBUTE32_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF": activity.ATTRIBUTE32_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF,
                                  "ATTRIBUTE33_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF": activity.ATTRIBUTE33_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF,
                                  "ATTRIBUTE36_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF": activity.ATTRIBUTE36_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF,
                                  "ATTRIBUTE4_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF": activity.ATTRIBUTE4_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF,
                                  "ATTRIBUTE5_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF": activity.ATTRIBUTE5_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF,
                                  "ATTRIBUTE8_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF": activity.ATTRIBUTE8_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF,
                                  "CASH_BATCH_ID": activity.CASH_BATCH_ID,
                                  "CLAIM_TYPE": activity.CLAIM_TYPE,
                                  "CONTRACT_BILLING_FREQUENCY": activity.CONTRACT_BILLING_FREQUENCY,
                                  "CONTRACT_EFFECTIVE_DATE": activity.CONTRACT_EFFECTIVE_DATE,
                                  "CONTRACT_ID": activity.CONTRACT_ID,
                                  "ENTERED_CREDIT_AMOUNT": activity.ENTERED_CREDIT_AMOUNT,
                                  "ENTERED_DEBIT_AMOUNT": activity.ENTERED_DEBIT_AMOUNT,
                                  "FINANCIAL_ACTIVITY_CLASS": activity.FINANCIAL_ACTIVITY_CLASS,
                                  "FINANCIAL_ACTIVITY_IDENTIFIER": activity.FINANCIAL_ACTIVITY_IDENTIFIER,
                                  "PAYMENT_INVOICE_NUMBER": activity.PAYMENT_INVOICE_NUMBER,
                                  "PREMIUM_TYPE": activity.PREMIUM_TYPE,
                                  "PRODUCT_CATEGORY": activity.PRODUCT_CATEGORY,
                                  "PRODUCT_IDENTIFIER": activity.PRODUCT_IDENTIFIER,
                                  "PRODUCT_TYPE": activity.PRODUCT_TYPE,
                                  "SEGMENT5": activity.SEGMENT5,
                                  "SEGMENT7": activity.SEGMENT7,
                                  "SURRENDER_TYPE": activity.SURRENDER_TYPE,
                                  "SUSPENSE_ACCOUNT_TYPE": activity.SUSPENSE_ACCOUNT_TYPE,
                                  "TRANSACTION_BRANCH": activity.TRANSACTION_BRANCH,
                                  "BREAKDOWN": activity.BREAKDOWN})
        DynamoDbWriter.put_batch(*list_of_items)

        return None

    def get_breakdown_list(self):
        self.breakdown_df = self.df_dict['FFA_BREAKDOWN'].fillna('None')
        self.breakdown_dict = self.breakdown_df.groupby('FINANCIAL_ACTIVITY_IDENTIFIER')[self.breakdown_df.columns].apply(
            lambda x: list(x.T.to_dict().values())).to_dict()

        return self.breakdown_dict

    def get_activity_breakdown_df(self):
        self.activity_df = self.df_dict['FFA_ACTIVITY'].fillna('None')
        self.breakdown_list = self.get_breakdown_list()
        self.activity_df['BREAKDOWN'] = None
        self.activity_df['BREAKDOWN'] = self.activity_df['FINANCIAL_ACTIVITY_IDENTIFIER'].apply(
            lambda x: self.breakdown_list.get(x))

        return self.activity_df


class DynamoDbWriter(DynaModel):
    class Table:
        name = 'ffa-finance-dt'
        hash_key = 'FINANCIAL_ACTIVITY_IDENTIFIER'
        read = 25
        write = 5

    class Schema:
        CURRENCY_CODE = fields.String()
        EFFECTIVE_DATE_OF_TRANSACTION = fields.String()
        JOURNAL_CATEGORY = fields.String()
        JOURNAL_ENTRY_CREATION_DATE = fields.String()
        AMOUNT = fields.String()
        ATTRIBUTE1_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF = fields.String()
        ATTRIBUTE2_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF = fields.String()
        ATTRIBUTE3_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF = fields.String()
        ATTRIBUTE32_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF = fields.String()
        ATTRIBUTE33_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF = fields.String()
        ATTRIBUTE36_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF = fields.String()
        ATTRIBUTE4_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF = fields.String()
        ATTRIBUTE5_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF = fields.String()
        ATTRIBUTE8_VALUE_FOR_JOURNAL_ENTRY_LINE_DFF = fields.String()
        CASH_BATCH_ID = fields.String()
        CLAIM_TYPE = fields.String()
        CONTRACT_BILLING_FREQUENCY = fields.String()
        CONTRACT_EFFECTIVE_DATE = fields.String()
        CONTRACT_ID = fields.String()
        ENTERED_CREDIT_AMOUNT = fields.String()
        ENTERED_DEBIT_AMOUNT = fields.String()
        FINANCIAL_ACTIVITY_CLASS = fields.String()
        FINANCIAL_ACTIVITY_IDENTIFIER = fields.String()
        PAYMENT_INVOICE_NUMBER = fields.String()
        PREMIUM_TYPE = fields.String()
        PRODUCT_CATEGORY = fields.String()
        PRODUCT_IDENTIFIER = fields.String()
        PRODUCT_TYPE = fields.String()
        SEGMENT5 = fields.String()
        SEGMENT7 = fields.String()
        SURRENDER_TYPE = fields.String()
        SUSPENSE_ACCOUNT_TYPE = fields.String()
        TRANSACTION_BRANCH = fields.String()
        BREAKDOWN = fields.List(fields.Dict)

from aegon_datalake_common.config_module.configProvider.processor import Processor
from com.aegonlife.publication.core.handler.FileProcessor import FileProcessor
from .DynamormProcessor import DynamormProcessor


class FinanceBuilder:
    def __init__(self, df_dict, config_item:Processor, config_key, file_to_be_processed):
        """To generate Finance lines for FFA activity and breakdown as single entity and publish to dynamo db"""
        self.df_dict = df_dict
        self.config_key = config_key
        self.config_item = config_item
        self.file_format = self.config_item.inputFormat
        self.file = self.config_item.file
        self.system = self.config_item.system
        self.file_to_be_processed = file_to_be_processed

    def process_event(self):

        file_processor_obj = FileProcessor(self.config_item)
        self.df = file_processor_obj.read_file(self.file_format, self.file_to_be_processed)
        self.df = file_processor_obj.rename_columns(self.df)
        self.df_dict = file_processor_obj.get_df_dict(self.config_key, self.df_dict)
        file_processor_obj.write_file()

        # Write to dynamo - to be finalised
        finance_file_items = ['FFA_ACTIVITY', 'FFA_BREAKDOWN']
        if all(finance_item in self.df_dict for finance_item in finance_file_items):
            DynamormProcessor.write_to_dynamo()




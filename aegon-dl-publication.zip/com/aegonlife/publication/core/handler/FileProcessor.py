from aegon_datalake_common.config_module.configProvider.processor import Processor
from ..reader.ReaderFactory import ReaderFactory
from ..writer.WriterFactory import WriterFactory
import pandas as pd
import boto3


class FileProcessor:
    def __init__(self, config_item: Processor):
        self.config_item = config_item
        self.output = self.config_item.outputs.output
        self.mapping = self.config_item.mapping
        self.df = None
        self.df_mapping = pd.DataFrame()
        self.dynamodb = boto3.resource('dynamodb')
        self.unique_key = self.config_item.uniqueKey
        self.file_processor_response = []
        self.workflow_response = {}

    def read_file(self, file_format, file_to_be_processed):
        reader_obj = ReaderFactory.get_s3_reader(file_format, file_to_be_processed, self.config_item)
        self.df = reader_obj.read_file()
        return self.df

    def rename_columns(self, df_transformed):
        self.df = self.set_system_attributes(df_transformed)
        if len(self.mapping) > 0:
            for tgt_col, src_col in self.mapping.items():
                self.df_mapping[tgt_col] = self.df[src_col] if src_col != "" else ""
            self.df = self.df_mapping
            return self.df
        else:
            return self.df

    def set_system_attributes(self, df_transformed):
        if self.config_item.file == 'aged_suspense':
            df_transformed['source_system'] = self.config_item.system
            df_transformed['end_date'] = ''
        return df_transformed


    def write_file(self, file_meta_data_key):
        if not self.df.empty:
            for output_item in self.output:
                writer_obj = WriterFactory.write_to_target(output_item.outputWriter, self.config_item, self.df)
                response = writer_obj.write_df(file_meta_data_key)
                self.file_processor_response.append(response)
            return self.file_processor_response

    def get_df_dict(self, config_key, df_dict):  # df_read
        # self.df = df_read
        df_dict[config_key] = self.df
        return df_dict

    def send_request_to_workflow_manager(self, processor_status):
        self.workflow_response['file_identifier'] = '20240869'
        self.workflow_response['file_name'] = 'Activity_20240869.csv'
        self.workflow_response['status'] = processor_status

        print('self.workflow_response', self.workflow_response)

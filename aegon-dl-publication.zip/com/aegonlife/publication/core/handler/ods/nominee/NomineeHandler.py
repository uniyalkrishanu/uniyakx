import pandas as pd
import boto3

from aegon_datalake_common.config_module.configProvider.processor import Processor
from com.aegonlife.publication.core.handler.FileProcessor import FileProcessor


class NomineeHandler:
    def __init__(self, config_key, file_to_be_processed, config_item: Processor, file_meta_data_key):
        """Handler to process Nominee file"""
        self.config_key = config_key
        self.file_to_be_processed = file_to_be_processed
        self.config_item = config_item
        self.file_format = self.config_item.inputFormat
        self.unique_key = self.config_item.uniqueKey
        self.dynamodb = boto3.resource('dynamodb')
        self.file_meta_data_key = file_meta_data_key
        self.df = None

    def process_event(self):
        file_processor_obj = FileProcessor(self.config_item)
        self.df = file_processor_obj.read_file(self.file_format, self.file_to_be_processed)
        self.df = self.get_nominee_list()
        self.df = self.add_nominee_list_to_policy_master()
        self.df = file_processor_obj.rename_columns(self.df)
        processor_status = file_processor_obj.write_file(self.file_meta_data_key)
        file_processor_obj.send_request_to_workflow_manager(processor_status)


    def get_nominee_list(self):

        nominee_dict = self.df.groupby('policy_number')[self.df.columns].apply(
            lambda x: list(x.T.to_dict().values())).to_dict()
        self.df['NOMINEE'] = self.df[self.unique_key].apply(lambda x: nominee_dict.get(x))
        self.df = self.df[[self.unique_key, 'NOMINEE']]

        return self.df

    def add_nominee_list_to_policy_master(self):
        row_for_df = []
        ods_table = 'ow-policy-master-dt'
        table = self.dynamodb.Table(ods_table)
        #self.df[self.unique_key] = self.df[self.unique_key].astype('int64')
        policy_number_list = set(self.df[self.unique_key].tolist())
        for policy_number in policy_number_list:
            response = table.query(
                Select='ALL_ATTRIBUTES',
                ConsistentRead=True,
                KeyConditions={
                    'policy_number': {'AttributeValueList': [str(policy_number)], 'ComparisonOperator': 'EQ'}
                },
                ScanIndexForward=False,
                ReturnConsumedCapacity='TOTAL'
            )
            item = response['Items'][0] if len(response['Items']) > 0 else []
            if len(item) > 0:
                row_for_df.append(item)
        policy_master_df = pd.DataFrame(row_for_df)
        policy_master_df = policy_master_df.drop(columns=['NOMINEE'])
        if len(policy_master_df.index) > 0:
            self.df = pd.merge(self.df, policy_master_df, on=self.unique_key, how='left')
        return self.df

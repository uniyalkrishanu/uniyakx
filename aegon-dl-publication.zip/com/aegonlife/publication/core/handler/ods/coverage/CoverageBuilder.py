from aegon_datalake_common.config_module.configProvider.processor import Processor
from com.aegonlife.publication.core.handler.FileProcessor import FileProcessor

class CoverageBuilder:
    def __init__(self, config_key, file_to_be_processed, config_item:Processor, file_meta_data_key):
        """Handler to process coverage file"""
        self.config_key = config_key
        self.file_to_be_processed = file_to_be_processed
        self.config_item = config_item
        self.file_format = self.config_item.inputFormat
        self.file_meta_data_key = file_meta_data_key
        self.df = None

    def process_event(self):

        file_processor_obj = FileProcessor(self.config_item)
        self.df = file_processor_obj.read_file(self.file_format, self.file_to_be_processed)
        self.df = file_processor_obj.rename_columns(self.df)
        file_processor_obj.write_file(self.file_meta_data_key)


import numpy as np
import pandas as pd
import aegon_datalake_common.utils.look_up as lookup


class ColumnTransformation:
    """ColumnTransformation: to perform column level transformation on input file
            (
            df = inputFile dataframe,
            system = system name,
            file_name = file of system,
            column_to_lookup = checking lookup value for,
            input_column_list = fields to lookup on,
            column_transform = new column with look up value
            )"""

    def __init__(self, df, system, file_name, column_to_lookup, input_column_list, column_transform):
        self.df = df
        self.system = system
        self.file_name = file_name
        self.column_to_lookup = column_to_lookup
        self.input_column_list = input_column_list
        self.column_transform = column_transform

    def suspense_type_lookup(self):

        lookup_received_list = []
        lookup_received_list = lookup.get_config(self.system, self.file_name)  # , column_name=self.column_to_lookup
        for item in range(len(lookup_received_list)):
            lookup_received_list[item] = lookup_received_list[item].to_dict()

        '''lookup_value_series = self.df.groupby(self.input_column_list).size()
        lookup_value_list = list(map(list, [k for k, v in lookup_value_series.iteritems()]))

        for lookup_value_item in lookup_value_list:
            # newValue = self.getSuspenseLookupValue(self.system, self.columnToLookup, lookupValueItem)
            lookup_reader_obj = DynamoReader(self.system, self.file_name, self.column_to_lookup, lookup_value_item)
            new_value = lookup_reader_obj.get_record()
            lookup_received_dict = {'system': self.system, 'columnToLookup': self.column_to_lookup, 'lookupValueItem': lookup_value_item,
                                  'newValue': new_value}
            lookup_received_list.append(lookup_received_dict)'''

        lookup_df = pd.DataFrame(lookup_received_list)
        lookup_df['lookupValueItem'] = lookup_df[['lookup1', 'lookup2']].values.tolist()

        for index, row in lookup_df.iterrows():
            if row['column_name'] == self.column_to_lookup:
                self.df[self.column_transform] = np.where(
                    (self.df[self.input_column_list] == row['lookupValueItem']).all(axis=1), row['output_value'],
                    self.df[self.column_transform])
        # self.df[self.columnTransform] = self.df.apply(lambda row: self.getSuspenseValue(row[self.columnTransform], [row[self.inputColumnList[0]], row[self.inputColumnList[1]]]), axis=1)
        return self.df


class RecordTransformation:
    def __init__(self, df, value_list):
        """RecordTransformation: to perform row level operation on input file
            (
            df = inputFile dataframe
            value_list = contains identifier list for record level transformation
            ) """
        self.df = df
        self.value_list = value_list
        self.df_to_process = None
        self.df_unprocessed = None
        self.df_replicated = None

    def calc_advance_excess_premium_amount(self, amount, next_modal_prem):
        next_modal_prem = 1 if next_modal_prem == 0 else next_modal_prem
        excess_prem_amount = amount % next_modal_prem
        advance_prem_amount = amount - excess_prem_amount
        return [excess_prem_amount, advance_prem_amount]

    def get_new_reason_and_amount(self, line_no, excess_prem_amount, advance_prem_amount):
        reason_new = 'EXCESS PREMIUM' if line_no == 1 else 'ADVANCE PREMIUM'
        amount = excess_prem_amount if reason_new == 'EXCESS PREMIUM' else advance_prem_amount
        return [reason_new, amount]

    def advance_prem_generator(self):
        for value_item_list in self.value_list:
            # value_item_list = eval(value_item_list)
            self.df_to_process = self.df[
                (self.df['suspense_account_type'] == value_item_list[0]) & (self.df['reason'] == value_item_list[1])]
            self.df_unprocessed = pd.concat([self.df, self.df_to_process]).drop_duplicates(keep=False)
            self.df_to_process[['next_modal_prem', 'amount']].replace(np.nan, 0)
            self.df_to_process[['next_modal_prem', 'amount']] = self.df_to_process[['next_modal_prem', 'amount']].astype(float)
            self.df_to_process[['excess_prem_amount', 'advance_prem_amount']] = self.df_to_process.apply(
                lambda row: self.calc_advance_excess_premium_amount(row['amount'], row['next_modal_prem']), axis=1, result_type='expand')

            # replicating Lines for advance premium
            self.df_replicated = pd.DataFrame(np.repeat(self.df_to_process.values, 2, axis=0))
            self.df_replicated.columns = self.df_to_process.columns
            self.df_replicated['line_no'] = self.df_replicated.groupby(['contract_no']).cumcount() + 1
            self.df_replicated[['reason_revised', 'amount']] = self.df_replicated.apply(
                lambda row: self.get_new_reason_and_amount(row['line_no'], row['excess_prem_amount'], row['advance_prem_amount']), axis=1,
                result_type='expand')

            # Removing in-process attributes
            self.df_replicated = self.df_replicated.drop(['excess_prem_amount', 'advance_prem_amount', 'line_no'], axis=1)
            self.df_replicated = self.df_replicated[self.df_replicated['amount'] > 0]

            self.df = pd.concat([self.df_unprocessed, self.df_replicated])
        return self.df

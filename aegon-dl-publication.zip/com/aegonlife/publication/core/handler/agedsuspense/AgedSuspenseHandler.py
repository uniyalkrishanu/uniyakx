from aegon_datalake_common.config_module.configProvider.processor import Processor
from com.aegonlife.publication.core.handler.FileProcessor import FileProcessor
from .ValueTransformation import *
import boto3
from ...writer.TargetWriter import S3CsvWriter


class AgedSuspenseHandler:

    def __init__(self, file_to_be_processed, config_item: Processor, file_meta_data_key):
        """Handler to process aged_suspense file for old world suspense"""
        self.config_item = config_item
        self.file_format = self.config_item.inputFormat
        self.file_to_be_processed = file_to_be_processed
        self.dynamodb = boto3.resource('dynamodb')
        self.unique_key = self.config_item.uniqueKey
        self.file_meta_data_key = file_meta_data_key

    def process_event(self):
        file_processor_obj = FileProcessor(self.config_item)
        self.df = file_processor_obj.read_file(self.file_format, self.file_to_be_processed)
        self.df = TransformData(self.df, self.config_item).value_transformation()
        self.df = self.get_ods_mapping(self.df)
        self.df = file_processor_obj.rename_columns(self.df)
        file_processor_obj.write_file(self.file_meta_data_key)

    def get_ods_mapping(self, df):
        row_for_df = []
        self.df = df
        self.df[self.unique_key] = self.df[self.unique_key]
        ods_table = 'ow-policy-master-dt'
        table = self.dynamodb.Table(ods_table)
        policy_number_list = set(self.df[self.unique_key].tolist())
        for policy_number in policy_number_list:
            response = table.query(
                Select='SPECIFIC_ATTRIBUTES',
                AttributesToGet=['policy_number', 'product_code', 'product_name', 'status_change_date', ],
                ConsistentRead=True,
                KeyConditions={
                    'policy_number': {'AttributeValueList': [policy_number], 'ComparisonOperator': 'EQ'}
                },
                ScanIndexForward=False,
                ReturnConsumedCapacity='TOTAL'
            )

            item = response['Items'][0] if len(response['Items']) > 0 else []
            if len(item) > 0:
                row_for_df.append(item)
        ods_df = pd.DataFrame(row_for_df, columns=['policy_number', 'product_code', 'product_name',
                                                   'status_change_date'])
        ods_df[self.unique_key] = ods_df['policy_number']
        self.df = pd.merge(self.df, ods_df, on=self.unique_key, how='left')
        return self.df


class TransformData:

    def __init__(self, df_read, config_item: Processor):
        """To perform custom Row/Column level transformation operations"""
        self.df = df_read
        self.config_item = config_item
        self.transformation = self.config_item.transformations
        self.system = self.config_item.system
        self.file_name = self.config_item.file

    def value_transformation(self):
        if self.transformation is not None:
            if 'columnTransformation' in self.transformation.value:
                self.df = self.column_transformation(self.transformation.ColumnTransformations)
            if 'recordTransformation' in self.transformation.value:
                self.df = self.record_transformation(self.transformation.RecordTransformation)
        return self.df

    def column_transformation(self, transformation_item):

        for CT_item in transformation_item:
            rule_name = CT_item.ruleName
            column_to_process = CT_item.columnName
            input_column_list = CT_item.inputList.split(',')

            # Original values required for multiple column transformation
            column_transform = column_to_process + '_revised'
            self.df[column_transform] = ''  # self.df[column_to_process]

            column_transformation_obj = ColumnTransformation(self.df, self.system, self.file_name, column_to_process,
                                                             input_column_list,
                                                             column_transform)
            if rule_name == 'suspense_type_lookup':
                self.df = column_transformation_obj.suspense_type_lookup()

        return self.df

    def record_transformation(self, transformation_item):

        for item in transformation_item:
            rule_name = item.ruleName
            value_list = item.valueList

            record_transformation_obj = RecordTransformation(self.df, value_list)
            if rule_name == 'advance_prem_generator':
                self.df = record_transformation_obj.advance_prem_generator()

        return self.df

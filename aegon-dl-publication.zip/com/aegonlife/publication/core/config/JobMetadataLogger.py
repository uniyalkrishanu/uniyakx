import boto3
import os
import json
from decimal import Decimal
from boto3.dynamodb.conditions import Key, Attr
from datetime import datetime
from aegon_datalake_common.utils.job_metadata_logger import write_job_metadata


class JobMetadataLogger:

    def __init__(self, file_name, batch_id):
        self.file_name = file_name
        self.batch_id = batch_id
        #self.input_key = input_key
        self.job_name = 'PROCESSOR_LAMBDA'
        self.dynamodb = boto3.resource('dynamodb')
        #self.config_tbl = self.dynamodb.Table(os.environ['FileMetadataLog'])  # aegone-datalake-file-master-dt
        self.payload_job_metadata = None

    def log_event(self):
        write_job_metadata(self.file_name, self.batch_id, status='failed', file_count='100')

    def get_job_meta_data(self, file_name, batch_id):
        self.file_name = file_name
        self.batch_id = batch_id
        self.payload_job_metadata = self.config_tbl.query(KeyConditionExpression=Key('filename').eq(self.file_name),
                                                          FilterExpression=Attr('batch_id').eq(self.batch_id))
        return self.payload_job_metadata['Items'][0]

    def update_job_metadata(self, action):
        self.payload_job_metadata = self.get_job_meta_data(self.file_name, self.batch_id)
        # To Check in Job Metadata is present
        if self.payload_job_metadata is not None:
            if action == 'started':
                start_time = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f')
                # self.inputKey = self.payload_JobMetadata['inputKey']
                payload_job_details = {'job_name': self.job_name, 'start_time': start_time, 'status': 'STARTED',
                                        'outputFileKey': 'NA'} #'inputFileKey': self.input_key,
                # TO check status is logged once
                for Job_details in self.payload_job_metadata['job_details']:

                    if 'PROCESSOR_LAMBDA' not in Job_details.values():
                        self.payload_job_metadata['job_details'].append(payload_job_details)
                        self.payload_job_metadata = json.loads(json.dumps(self.payload_job_metadata), parse_float=Decimal)
                        response = self.config_tbl.put_item(Item=self.payload_job_metadata)
                        return response

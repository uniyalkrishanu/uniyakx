import boto3
import os
from boto3.dynamodb.conditions import Key, Attr
import json
from aegon_datalake_common.config_module import get_config
from aegon_datalake_common.utils import look_up


class DynamoDbReader:

    def __init__(self, config_key):
        self.config_key = config_key
        self.config_type = 'processor'
        self.dynamo_table_name = 'aegone-datalake-ffa-file-config-dt'
        self.dynamodb = boto3.resource('dynamodb')
        self.config_item = None
        # self.config_tbl = self.dynamodb.Table(os.environ['FileConfigTable'])  # aegone-datalake-ffa-file-config-dt

    def dynamo_config_reader(self):

        self.config_item = get_config(self.config_key, self.config_type, self.dynamo_table_name)
        return self.config_item


class S3ConfigReader:

    def __init__(self, config_key):
        self.config_key = config_key
        self.s3 = boto3.resource('s3')
        # self.config_bucket = os.environ['configbucket']
        self.config_bucket = 'aegon-publication-datalake-store-dt'

    def s3_config_reader(self):
        print('self.configKey', self.config_key)
        for object in self.s3.Bucket(self.config_bucket).objects.filter(Prefix=("config_publicationflow/" + self.config_key)):
            if self.config_key in object.key:
                self.config_key = object.key
                obj = self.s3.Object(self.config_bucket, self.config_key)
                body = obj.get()['Body'].read().decode('utf-8')
                config_file_items = json.loads(body)
                return config_file_items
            else:
                print("config.json not available for {}".format(self.config_key))

from aegon_datalake_common.config_module.configProvider import ConfigProvider


def get_config(file_name, config_type, table_name):
    return ConfigProvider.Config.get_config(file_name, config_type, table_name)
class MetaData:
    def __init__(self, metadata):
        self.value = metadata
        self.apply_business_rules = metadata['apply_business_rules']
        self.content_type = metadata['content_type']
        self.delimiter_type = metadata['delimiter_type']
        self.filename_pattern = metadata['filename_pattern']
        self.input_type = metadata['input_type']
        self.load_type = metadata['load_type']
        self.priority = metadata['priority']
        self.record_limit = metadata['record_limit']
        self.sep = metadata['sep']
        self.source_nm = metadata['source_nm']
        self.source_type = metadata['source_type']
        self.suffix = metadata['suffix']


class Fields:
    def __init__(self, fields):
        self.value = fields
        self.field = self.create_field(fields)

    @staticmethod
    def create_field(records):
        filed_list = []
        for record in records:
            filed_list.append(Field(record))
        return filed_list


class Field:
    def __init__(self, record):
        self.value = record
        self.column_name = record['column_name']
        self.data_type = record['data_type']
        self.dqm_check_list = DQMCheck(record.get('dqm_check_list', ''))
        self.dqm_hold_list = DQMHold(record.get('dqm_hold_list', ''))
        self.length = record['length']
        self.rename_to = record['rename_to']


class DQMCheck:
    def __init__(self, records):
        self.value = records
        self.dqm_discrete_value_check = records.get('dqm_discrete_value_check', '') if records != '' else ''
        self.dqm_null_check = records.get('dqm_null_check', '') if records != '' else ''
        self.dqm_length_check = records.get('dqm_length_check', '') if records != '' else ''


class DQMHold:
    def __init__(self, record):
        self.value = record
        self.dqm_discrete_value_hold = record.get('dqm_discrete_value_hold', '') if record != '' else ''
        self.dqm_null_hold = record.get('dqm_discrete_value_hold', '') if record != '' else ''


class Validator:
    def __init__(self, config_dict):
        self.fields = Fields(config_dict['fields'])
        self.file_control_nm = config_dict['file_control_nm']
        self.filename_pattern = config_dict['filename_pattern']
        self.metadata = MetaData(config_dict['metadata'])
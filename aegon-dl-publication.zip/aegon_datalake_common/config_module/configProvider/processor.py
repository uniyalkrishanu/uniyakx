class Outputs:
    def __init__(self, outputs):
        self.value = outputs
        self.output = self.create_outputs(outputs)

    @staticmethod
    def create_outputs(outputs):
        output_list = []
        for output in outputs:
            output_list.append(Output(output))
        return output_list


class Output:
    def __init__(self, record):
        self.value = record
        self.outputWriter = record['outputWriter']
        self.outputBucket = record.get('outputBucket', '')
        self.outputPath = record.get('outputPath', '')
        self.schema = record.get('schema', '')
        self.table = record.get('table', '')
        self.activeRecordUniqueKey = record.get('activeRecordUniqueKey', '')
        self.dbUniqueKey = record.get('dbUniqueKey', '')
        self.partitionKey = record.get('partitionKey', '')
        self.sortKey = record.get('sortKey', '')
        self.PartitionKeyName = record.get('PartitionKeyName', '')


class Transformation:
    def __init__(self, record):
        self.value = record
        self.ColumnTransformations = self.create_column_transformation(record.get('columnTransformation', ''))
        self.RecordTransformation = self.create_record_transformation(record.get('recordTransformation', ''))

    @staticmethod
    def create_column_transformation(records):
        column_transformation_list = []
        for record in records:
            column_transformation_list.append(ColumnTransformation(record))
        return column_transformation_list

    @staticmethod
    def create_record_transformation(records):
        column_transformation_list = []
        for record in records:
            column_transformation_list.append(RecordTransformation(record))
        return column_transformation_list


class ColumnTransformation:
    def __init__(self, record):
        self.value = record
        self.columnName = record['columnName']
        self.inputList = record['inputList']
        self.ruleName = record['ruleName']


class RecordTransformation:
    def __init__(self, record):
        self.value = record
        self.inputList = record['inputList']
        self.ruleName = record['ruleName']
        self.valueList = record['valueList']


class Processor:
    def __init__(self, config_dict):
        self.inputBucket = config_dict['inputBucket']
        self.inputFormat = config_dict['inputFormat']
        self.outputs = Outputs(config_dict['output'])
        self.delimiter = config_dict['delimiter']
        self.system = config_dict['system']
        self.file = config_dict['file']
        self.uniqueKey = config_dict['uniqueKey']
        self.mapping = config_dict['mapping']
        self.transformations = Transformation(config_dict['transformation'])

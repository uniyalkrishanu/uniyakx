from aegon_datalake_common.config_module.configProvider.validator import Validator
from aegon_datalake_common.config_module.configProvider.processor import Processor
from aegon_datalake_common.config_module.reader import DynamoReader


class Config:
    @staticmethod
    def get_config(config_name, config_type, table_name):
        if config_type == 'processor':
            return Config.get_process_config(config_name, config_type,  table_name)
        elif config_type == 'validator':
            return Config.get_validation_config(config_name, config_type, table_name)

    def get_process_config(config_name, config_type, table_name):
        config_dict = DynamoReader.DynamoReader.get_config_from_file_name(config_name, config_type, table_name)
        config_obj = Processor(config_dict)
        return config_obj

    def get_validation_config(config_name, config_type, table_name):
        config_dict = DynamoReader.DynamoReader.get_config_from_file_name(config_name, config_type, table_name)
        config_obj = Validator(config_dict)
        return config_obj

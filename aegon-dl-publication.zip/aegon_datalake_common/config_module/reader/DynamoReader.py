import boto3
import re
import os
from boto3.dynamodb.conditions import Key

class DynamoReader:
    def __init__(self, partition_key,  sort_key):
        self.partition_key = partition_key
        self. sort_key = sort_key

    @staticmethod
    # TODo: query for partition and sort key on aegone-datalake-ffa-file-config-dt
    def get_config_from_file_name(file_name, config_type, table_name):
        dynamodb = boto3.resource('dynamodb', region_name="ap-south-1")
        #table_name = os.environ.get('CONFIG_TABLE_NAME')
        table = dynamodb.Table(table_name)
        if config_type == 'validator':
            response = table.scan()
            data = response['Items']
            dynamo_items = [k for k in data if re.match(k['filename_pattern'], file_name, re.IGNORECASE)]
        else:
            response = table.query(KeyConditionExpression=Key('file_control_nm').eq(file_name) & Key('config_type').eq(config_type))
            dynamo_items = response['Items']
        if len(dynamo_items) == 1:
            return dynamo_items[0]
        elif len(dynamo_items) == 0:
            raise Exception('No config file found for this file_name {}', file_name)
        else:
            raise Exception('More than one config file found for this file_name {}', file_name)
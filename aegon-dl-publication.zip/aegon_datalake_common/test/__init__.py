from aegon_datalake_common.utils.look_up.reader.DynamoReader import DynamoReader
from aegon_datalake_common.utils.look_up.writer.DynamoWriter import DynamoWriter
from aegon_datalake_common.utils import look_up
from aegon_datalake_common.utils.look_up.domain.LookupEntity import Lookup


systemname = 'FFA'
filename = 'aged_suspense'
column_name = 'suspense_account_type'
lookupList = ['CWA Suspense', 'Cash With Application']
output = 'New Business Suspense'

# writer
'''
writerobj = DynamoWriter(systemname, filename, column_name, lookupList, output)
writerobj.put_record()
'''

# reader
'''
obj = DynamoReader(systemname, filename, column_name, lookupList)
rec = obj.get_record()
print('***********')
print(obj.get_lookup_value())
print(rec)
'''

systemname = 'FFA'
file_name = 'aged_suspense'

v = look_up.get_config(systemname, filename, columnname='reason')

for x in v:
    print('***')
    print(x.to_dict())
    print(x.system_name)
    print(x.system_name)
    print(x.output_value)
    print('Done')
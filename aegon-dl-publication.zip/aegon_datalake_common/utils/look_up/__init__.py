from aegon_datalake_common.utils.look_up.domain.LookupEntity import Lookup
from aegon_datalake_common.utils.look_up.reader.DynamoReader import DynamoReader
from aegon_datalake_common.utils.look_up.writer.DynamoWriter import DynamoWriter
from aegon_datalake_common.utils.look_up.writer import validate_kwargs_for_write
from aegon_datalake_common.utils.look_up.reader import validate_kwargs_for_read


# List Method
def get_lookup_config(system_name, file_name, column_name, lookup_list):
    obj = DynamoReader(system_name, file_name, column_name, lookup_list)
    return obj.get_record()


'''
def write_lookup_config(system_name, file_name, column_name, lookup_list, output):
    writer_obj = DynamoWriter(system_name, file_name, column_name, lookup_list, output)
    writer_obj.put_record()

def get_lookup_value(system_name, file_name, column_name, lookup_list):
    obj = DynamoReader(system_name, file_name, column_name, lookup_list)
    return obj.get_lookup_value()
'''


# ORM method
def get_config(system_name, file_name, **kwargs):
    kwargs['system_name'] = system_name.strip()
    kwargs['file_name'] = file_name.strip()
    kwargs = validate_kwargs_for_read(**kwargs)
    results = Lookup.query(**kwargs)
    list(results)
    lookup_obj_list = []
    for x in results.resp['Items']:
        lookup_obj = Lookup.new_from_raw(x)
        lookup_obj_list.append(lookup_obj)
    return lookup_obj_list


def write_config(**kwargs):
    kwargs = validate_kwargs_for_write(**kwargs)
    Lookup(**kwargs).save()


def get_config_non_strict(**kwargs):
    pass






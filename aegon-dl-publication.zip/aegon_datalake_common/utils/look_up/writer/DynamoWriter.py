import boto3
import hashlib
from aegon_datalake_common.utils.look_up.domain.LookupEntity import Lookup


class DynamoWriter:

    def __init__(self, system_name, file_name, column_name, lookup_list, output_value, is_active='Y'):
        self.system_name = system_name.strip()
        self.file_name = file_name.strip()
        self.column_name = column_name.strip()
        self.lookup1 = ''
        self.lookup2 = ''
        self.lookup3 = ''
        self.output_value = output_value.strip()
        self.is_active = is_active.strip()
        self.assign_lookup_value(lookup_list)

    def assign_lookup_value(self, lookup_list):
        assign_list = ['lookup1', 'lookup2', 'lookup3']
        for i in range(0, len(lookup_list)):
            setattr(self, assign_list[i], lookup_list[i])

    def generate_sha256(self):
        sort_key = self.column_name+self.lookup1+self.lookup2+self.lookup3
        hash_sha256 = hashlib.new("sha256", sort_key.encode())
        return hash_sha256.hexdigest()

    def put_record(self):
        system_file = self.system_name+'_'+self.file_name
        ids = self.generate_sha256()
        lookup_data = Lookup(SystemFile=system_file, id=ids, column_name=self.column_name, lookup1=self.lookup1, lookup2=self.lookup2, lookup3=self.lookup3, output_value=self.output_value, is_active=self.is_active)
        lookup_data.save()
        print('Data got saved')

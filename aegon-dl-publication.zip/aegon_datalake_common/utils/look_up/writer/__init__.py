import hashlib


def generate_sha256(**kwargs):
    sort_key = kwargs['column_name']+kwargs['lookup1']+kwargs['lookup2']+kwargs['lookup3']
    hash_sha256 = hashlib.new("sha256", sort_key.encode())
    return hash_sha256.hexdigest()


def validate_kwargs_for_write(**kwargs):
    req_keys = ['system_name', 'file_name', 'column_name', 'lookup1', 'lookup2', 'lookup3', 'output_value', 'is_active']
    actual_keys = list(kwargs.keys())
    if 'is_active' not in actual_keys:
        actual_keys.append('is_active')
        kwargs['is_active'] = 'Y'
    kwargs = {key: value.strip() for key, value in kwargs.items()}
    if set(req_keys) == set(actual_keys):
        kwargs['module_name'] = kwargs['system_name'] + '_' + kwargs['file_name']
        kwargs['id'] = generate_sha256(**kwargs)
        del kwargs['system_name']
        del kwargs['file_name']
        return kwargs
    else:
        raise Exception('KeyError: required keys are {}'.format(req_keys))
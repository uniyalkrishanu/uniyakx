

def validate_kwargs_for_read(**kwargs):
    kwargs = {key.strip(): value.strip() for key, value in kwargs.items()}
    mandatory_key = ['system_name', 'file_name']
    optional_keys = ['column_name', 'lookup1', 'lookup2', 'lookup3', 'output_value', 'is_active']
    req_keys = mandatory_key + optional_keys
    actual_keys = list(kwargs.keys())

    if not all(item in actual_keys for item in mandatory_key):
        raise Exception('KeyError: Need Key {} '.format(mandatory_key))

    if 'is_active' not in actual_keys:
        actual_keys.append('is_active')
        kwargs['is_active'] = 'Y'

    if len(set(actual_keys) - set(req_keys)) == 0:
        kwargs['module_name'] = kwargs['system_name'] + '_' + kwargs['file_name']
        del kwargs['system_name']
        del kwargs['file_name']
        return kwargs
    else:
        raise Exception('KeyError: required keys are {}'.format(req_keys))
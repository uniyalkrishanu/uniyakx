import boto3
from boto3.dynamodb.conditions import Key
import hashlib
import sys
from botocore.exceptions import ClientError
from aegon_datalake_common.utils.look_up.domain.LookupEntity import Lookup
from dynamorm import DynaModel


class DynamoReader:

    def __init__(self, system_name, file_name, column_name, lookup_list, is_active='Y'):
        self.system_name = system_name.strip()
        self.file_name = file_name.strip()
        self.column_name = column_name.strip()
        self.lookup1 = ''
        self.lookup2 = ''
        self.lookup3 = ''
        self.is_active = is_active.strip()
        self.assign_lookup_value(lookup_list)

    def assign_lookup_value(self, lookup_list):
        assign_list = ['lookup1', 'lookup2', 'lookup3']
        for i in range(0, len(lookup_list)):
            setattr(self, assign_list[i], lookup_list[i])

    def generate_sha256(self):
        sort_key = self.column_name + self.lookup1 + self.lookup2 + self.lookup3
        hash_sha256 = hashlib.new("sha256", sort_key.encode())
        return hash_sha256.hexdigest()

    def get_record(self):
        system_file = self.system_name + '_' + self.file_name
        ids = self.generate_sha256()
        results = Lookup.query(SystemFile=system_file, id=ids, column_name=self.column_name, lookup1=self.lookup1, lookup2=self.lookup2, lookup3=self.lookup3, is_active=self.is_active)
        list(results)
        return results.resp['Items']

    def get_lookup_value(self):
        records = self.get_record()
        return records[0]['output_value']


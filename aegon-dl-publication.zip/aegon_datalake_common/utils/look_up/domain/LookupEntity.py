from dynamorm import DynaModel
from marshmallow import fields
import os

os.environ['AWS_DEFAULT_REGION'] = 'ap-south-1'


class Lookup(DynaModel):
    module_name = ''
    column_name = ''
    lookup1 = ''
    lookup2 = ''
    lookup3 = ''
    output_value = ''

    class Table:
        name = 'datalake-common-lookup-dt'
        hash_key = 'module_name'
        range_key = 'id'
        region_name = "ap-south-1"
        read = 5
        write = 5

    # Define our data schema, each property here will become a property on instances of the Book class
    class Schema:
        module_name = fields.String()
        id = fields.String(required=False)
        column_name = fields.String()
        lookup1 = fields.String()
        lookup2 = fields.String()
        lookup3 = fields.String()
        is_active = fields.String()
        output_value = fields.String()

    def __getattr__(self, attr):
        self.system_name = self.module_name.split('_')[0]
        self.file_name = '_'.join(self.module_name.split('_')[1:])
        return getattr(self, attr)

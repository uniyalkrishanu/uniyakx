from .JobMetadataLogger import FlowMetadataDao, FlowMetadata


def write_job_metadata(file_name, batch_id, **kwargs):
    kwargs = get_validated_schema(kwargs)

    fmdu = FlowMetadataDao(filename=file_name, batch_id=batch_id, status=kwargs['status'], job_details={},
                           summary_detail="", dqm_detail="", content_type="", created_at=kwargs.get('created_at'),
                           file_count=kwargs.get('file_count'), landing_count=kwargs.get('landing_count'), source_nm="", source_type="",
                           suffix="")
    fmdu.save()


def get_validated_schema(kwargs):
    landing_count = "" if kwargs.get('kwargs') is None else kwargs.get('kwargs')
    created_at = "" if kwargs.get('kwargs') is None else kwargs.get('kwargs')
    job_details = {} if kwargs.get('kwargs') is None else kwargs.get('kwargs')
    dict1 = {"filename": kwargs.get('filename'),
             "batch_id": kwargs.get('batch_id'),
             "created_at": created_at,
             "landing_count": landing_count,
             "file_count":kwargs.get('file_count'),
             "status":kwargs.get('status')}
    return dict1

import os
from dynamorm import DynaModel, GlobalIndex, ProjectAll

from marshmallow import fields, validate, validates, ValidationError

class FlowMetadata(DynaModel):
    class Table:
        name = 'FlowMetadata'
        hash_key = 'filename'
        range_key = 'batch_id'
        read = 5
        write = 1
        
    class Schema:
        filename = fields.String(required=True)
        batch_id = fields.String()
        status = fields.String(validate=validate.OneOf(('success', 'failed', 'inprogress')))
        job_details = fields.Dict(fields.String(),required=True)
        summary_detail = fields.List(fields.Dict(fields.String()),required=True)
        dqm_detail = fields.List(fields.Dict(fields.String()),required=True)
        content_type = fields.String()
        created_at = fields.String()
        file_count = fields.String()
        landing_count = fields.String()
        source_nm = fields.String()
        source_type = fields.String()
        suffix = fields.String()     

        @validates('job_details')
        def validate_name(self, value):
            # this is a very silly example just to illustrate that you can fill out the
            # inner Schema class just like any other Marshmallow class
            return
        
        @validates('summary_detail')
        def validate_name(self, value):
            # this is a very silly example just to illustrate that you can fill out the
            # inner Schema class just like any other Marshmallow class
            return
        
        @validates('dqm_detail')
        def validate_name(self, value):
            # this is a very silly example just to illustrate that you can fill out the
            # inner Schema class just like any other Marshmallow class
            return
        
class FlowMetadataDao():
  def __init__(self, filename, batch_id,status,job_details,summary_detail,dqm_detail,content_type,created_at,file_count,landing_count,source_nm,source_type,suffix):
    self.filename = filename
    self.batch_id = batch_id
    self.status = status
    self.job_details = job_details
    self.summary_detail = summary_detail
    self.dqm_detail = dqm_detail
    self.content_type = content_type
    self.created_at = created_at
    self.file_count = file_count
    self.landing_count = landing_count
    self.source_nm = source_nm
    self.source_type = source_type
    self.suffix = suffix
    
  def save(self):
      summarylist=list()
      dqmDetailslist=list()  
      for sl in self.summary_detail:
          summarylist.append(sl.__dict__)
      for dl in self.dqm_detail:
          dqmDetailslist.append(dl.__dict__)          
      fmdu = FlowMetadata(filename=self.filename,batch_id=self.batch_id,status=self.status,job_details=self.job_details,summary_detail=summarylist ,dqm_detail=dqmDetailslist,content_type=self.content_type ,created_at=self.created_at,file_count=self.file_count,landing_count=self.landing_count,source_nm=self.source_nm,source_type=self.source_type,suffix=self.suffix)
      fmdu.save()
      return
     
  def is_file_processed(filename):
      results = FlowMetadata.scan(filename=filename).limit(1)
      count = 0
      for model in results:
          count = count + 1
      return (count == 1)
  
class JobDetail:
  def __init__(self, inputFileKey, job_name,outputFileKey,start_time,status):
    self.inputFileKey = inputFileKey
    self.job_name = job_name
    self.outputFileKey = outputFileKey
    self.start_time = start_time    
    self.status = status       
    
class DqmDetail:
  def __init__(self, suspense_account_type, creation_date ,contract_no,client_id,id,VALIDATION_KEY,LEVEL,VALIDATION_RESULT,INPUT_SOURCE,INPUT_NAME,BATCH_ID,CREATED_AT):
    self.suspense_account_type = suspense_account_type
    self.creation_date  = creation_date
    self.contract_no = contract_no
    self.client_id = client_id   
    self.id = id       
    self.VALIDATION_KEY = VALIDATION_KEY   
    self.LEVEL = LEVEL   
    self.VALIDATION_RESULT = VALIDATION_RESULT   
    self.INPUT_SOURCE = INPUT_SOURCE   
    self.INPUT_NAME = INPUT_NAME   
    self.BATCH_ID = BATCH_ID       
    self.CREATED_AT = CREATED_AT
	 
class SummaryDetail:
  def __init__(self, level, validation_key,validation_result,input_source,input_name,batch_id,validation_count,CREATED_AT):
    self.level = level
    self.validation_key = validation_key
    self.validation_result = validation_result
    self.input_source = input_source    
    self.input_name = input_name       
    self.batch_id = batch_id    
    self.validation_count = validation_count  
    self.CREATED_AT = CREATED_AT  
    
							
def lambda_handler(event, context):
    
    FileName = event['FileName']
    batchId = event['batchId']
    response = FlowMetadata()
    return response
	

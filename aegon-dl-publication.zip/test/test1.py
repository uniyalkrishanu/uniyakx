# -*- coding: utf-8 -*-
"""
Created on Sat Apr 17 14:11:31 2021

@author: User
"""
from com.aegonlife.publication.interface.FileProcessingHandler import FileProcessingHandler
import json

event_ffa_agedsuspense = {
    "Records": {
        "Message":
            [
                {
                    "staging_file_key": "STAGING_FATP/FFA/FINANCE_SUSPENSE_DAILY/FFA_FINANCE_SUSPENSE_DAILY_b9bf8a41-c2a5-479c-b2bd-83e097d3ce0e.parquet",
                    "staging_bucket": "aegon-raw-datalake-store-dt",
                    "file_control_nm": "FFA_FINANCE_AGED_SUSPENSE_DAILY",
                    "file_name": "AGED_SUSPENSE_20210314.csv",
                    "batch_id": "3fec36f0-feeb-4d85-98fb-a67a85c96f96"
                }
            ]
    }
}

event_ffa_ofi = {
    "Records":
        {
            "Message":
                [
                    {
                        "staging_file_key": "STAGING_FATP/FFA_TEST/FINANCE_ACTIVITY_DAILY/activity_2004090314134.csv",
                        "file_name": "activity_200409031413.csv",
                        "staging_bucket": "aegon-staging-datalake-store-dt",
                        "file_control_nm": "FFA_ACTIVITY",
                        "batch_id": "02269352-ca8f-44f3-8380-5a3d8822b77c",
                        "staging_file_type": "csv",
                        "file": "ACTIVITY"
                    },
                    {
                        "staging_file_key": "STAGING_FATP/FFA_TEST/FINANCE_BREAKDOWN_DAILY/breakdown_200409031413.csv",
                        "file_name": "breakdown_200409031413.csv",
                        "staging_bucket": "aegon-staging-datalake-store-dt",
                        "file_control_nm": "FFA_BREAKDOWN",
                        "batch_id": "02269352-ca8f-44f3-8380-5a3d8822b77c",
                        "staging_file_type": "csv",
                        "file": "BREAKDOWN"
                    }
                ]
        }
}

event_policy_master = {
    "Records": {
        "Message":
            [
                {
                    "staging_file_key": "STAGING_FATP/FINANCE/POLICY_MASTER_FFA_DAILY/FINANCE_POLICY_MASTER_FFA_DAILY_9f0ab4f2-337f-4d0b-815d-acb4bea17f03.parquet",
                    "staging_bucket": "aegon-staging-datalake-store-dt",
                    "file_control_nm": "FFA_FINANCE_POLICY_MASTER_DAILY",
                    "file_name": "policy_master_210503025645.dat",
                    "batch_id": "3fec36f0-feeb-4d85-98fb-a67a85c96f96"
                }
            ]
    }
}

event_ods_coverage = {
    "Records": {
        "Message":
            [
                {
                    "staging_file_key": "STAGING_FATP/FINANCE/COVERAGE_FFA_DAILY/FINANCE_COVERAGE_FFA_DAILY_TESTLOCAL-006.parquet",
                    "staging_bucket": "aegon-staging-datalake-store-dt",
                    "file_control_nm": "FFA_FINANCE_COVERAGE_DAILY",
                    "file_name": "coverage_210430052504.dat",
                    "batch_id": "3fec36f0-feeb-4d85-98fb-a67a85c96f97"
                }
            ]
    }
}

event_hpms_Aged_suspense = {
    "Records": {
        "Message":
            [
                {
                    "staging_file_key": "STAGING_FATP/HPMS/FINANCE_SUSPENSE_DAILY/HPMS_FINANCE_SUSPENSE_DAILY_8ab2e07e-4b64-458b-972a-ab5fe2bd2bca.parquet",
                    "staging_bucket": "aegon-staging-datalake-store-dt",
                    "file_control_nm": "HPMS_AGED_SUSPENSE",
                    "file_name": "HPMS_AGED_SUSPENSE.csv",
                    "batch_id": "3fec36f0-feeb-4d85-98fb-a67a85c96f96"
                }
            ]
    }
}

event_ods_prpdep = {
    "Records": {
        "Message":
            [
                {
                    "staging_file_key": "STAGING_FATP/FINANCE/PRPDEP_FFA_DAILY/FINANCE_PRPDEP_FFA_DAILY_6960450a-06b4-43fd-abba-6010c52e6512.parquet",
                    "file_name": "prpdep_210430044413.dat",
                    "staging_bucket": "aegon-staging-datalake-store-dt",
                    "file_control_nm": "FFA_FINANCE_PRPDEP_DAILY",
                    "batch_id": "6960450a-06b4-43fd-abba-6010c52e6512",
                    "staging_file_type": "parquet"
                }
            ]
    }
}

event_ods_address = {
    "Records": {
        "Message":
            [
                {
                    "staging_file_key": "STAGING_FATP/FFA_TEST/ODS_ADDRESS/address_210430044413.dat",
                    "staging_bucket": "aegon-staging-datalake-store-dt",
                    "file_control_nm": "ODS_FINANCE_ADDRESS_DAILY",
                    "file_name": "ODS_FINANCE_ADDRESS_DAILY.csv",
                    "batch_id": "3fec36f0-feeb-4d85-98fb-a67a85c96f96"
                }
            ]
    }
}

event_ods_add_client_info = {
    "Records": {
        "Message":
            [
                {
                    "staging_file_key": "STAGING_FATP/FFA_TEST/ODS_ADD_CLIENT_INFO/add_client_info_210430044413.dat",
                    "staging_bucket": "aegon-staging-datalake-store-dt",
                    "file_control_nm": "ODS_FINANCE_ADD_CLIENT_INFO_DAILY",
                    "file_name": "ODS_FINANCE_ADD_CLIENT_INFO_DAILY.csv",
                    "batch_id": "3fec36f0-feeb-4d85-98fb-a67a85c96f96"
                }
            ]
    }
}

event_ods_nominee = {
    "Records": {
        "Message":
            [
                {
                    "staging_file_key": "STAGING_FATP/FINANCE/NOMINEE_FFA_DAILY/FINANCE_NOMINEE_FFA_DAILY_3964e3ec-5681-4899-9512-0178b45d115f.parquet",
                    "file_name": "nominee_210616023352.dat",
                    "staging_bucket": "aegon-staging-datalake-store-dt",
                    "file_control_nm": "FFA_FINANCE_NOMINEE_DAILY",
                    "batch_id": "3964e3ec-5681-4899-9512-0178b45d115f",
                    "staging_file_type": "parquet"
                }
            ]
    }
}

event_ods_add_client_info = {
    "Records": {
        "Message":
            [
                {
                    'staging_file_key': 'STAGING_FATP/FINANCE/ADD_CLIENT_INFO_FFA_DAILY/FINANCE_ADD_CLIENT_INFO_FFA_DAILY_0dc007e9-b342-4654-81ad-c331b10d972a.parquet',
                    'file_name': 'add_client_info_210430044413.dat',
                    'staging_bucket': 'aegon-staging-datalake-store-dt',
                    'file_control_nm': 'FFA_FINANCE_ADD_CLIENT_INFO_DAILY',
                    'batch_id': '0dc007e9-b342-4654-81ad-c331b10d972a',
                    'staging_file_type': 'parquet'
                }
            ]
    }
}

event_address = {
    "Records": {
        "Message":
            [
                {
                    "staging_file_key": "STAGING_FATP/FINANCE/ADDRESS_FFA_DAILY/FINANCE_ADDRESS_FFA_DAILY_11a25836-a5a1-487a-83a6-167184f58ad3.parquet",
                    "file_name": "address_210430044413.dat",
                    "staging_bucket": "aegon-staging-datalake-store-dt",
                    "file_control_nm": "FFA_FINANCE_ADDRESS_DAILY",
                    "batch_id": "11a25836-a5a1-487a-83a6-167184f58ad3",
                    "staging_file_type": "parquet"
                }
            ]
    }
}

# FileProcessingHandlerObj = FileProcessingHandler()
obj = FileProcessingHandler(event_ods_nominee, '')
print('obj', obj)

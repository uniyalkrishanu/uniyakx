from __future__ import print_function
import json
import traceback
import logging
import sys
from .snsHandler import snsHandler
from ..core.publicationFlow import publicationFlow
from ..exception.customException import *

logger = logging.getLogger(__name__)
logger.setLevel('INFO')

def fileProcessingHandler(event, context):
    logger.info('*************** Publication Processor Lambda execution started ***************')
    try:
        if 'Records' in event:
            for record in event['Records']:
                if 'sns' in record:
                    handler_obj = snsHandler(event['Records']['sns'], context)
                    configKey, fileToBeProcessed, fileMetaDataKey, batchId = handler_obj.snsHandler()
                    publicationFlowObj = publicationFlow(configKey, fileToBeProcessed, fileMetaDataKey, batchId)
                    publicationFlowObj.publicationProcessor()

    except FileConfigurationNotFound as e:
        response = {'exception':'FileConfigurationNotFound', 'errorCode':e.errorCode, 'errorMessage':e.errorMessage, 'errorPayload':e.errorPayload}
        logger.error(response)

    except FailedToReadFile as e:
        response = {'exception':'FailedToReadFile', 'errorCode':e.errorCode, 'errorMessage':e.errorMessage, 'errorPayload':e.errorPayload}
        logger.error(response)

    except Exception as e:
        logger.error("Unexpected error at generic handler:{}".format(sys.exc_info()[0]))
        logger.error(traceback.format_exc())
        return ({
            'statusCode': 400,
            'body': json.dumps('error in executing Publication Processor Lambda with error:{}' + format(sys.exc_info()[0]))
        })
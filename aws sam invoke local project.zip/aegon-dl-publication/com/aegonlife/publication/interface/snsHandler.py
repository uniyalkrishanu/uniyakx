import logging
import traceback
from com.aegonlife.publication.core.publicationFlow import publicationFlow


class snsHandler(object):
    def __init__(self, event, context):
        self.event = event
        self.context = context
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel('INFO')

    def snsHandler(self):
        try:
            configKey = self.event['fileControlNm']
            fileToBeProcessed = self.event['stagingFileKey']
            fileMetaDataKey = self.event['fileName']
            batchId = self.event['batchId']
            return configKey, fileToBeProcessed, fileMetaDataKey, batchId
        except Exception as e:
            self.logger.error(traceback.format_exc())

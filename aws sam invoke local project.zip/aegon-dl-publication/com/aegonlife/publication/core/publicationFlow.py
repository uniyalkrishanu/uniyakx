import logging

from com.aegonlife.publication.core.reader.ReaderFactory import ReaderFactory
from com.aegonlife.publication.core.writer.WriterFactory import WriterFactory
from com.aegonlife.publication.core.config.jobMetadataLogger import jobMetadataLogger
from com.aegonlife.publication.core.config.configProvider import *
from com.aegonlife.publication.core.agedsuspense.agedSuspenseTransformHandler import transformColumns
from com.aegonlife.publication.exception.customException import FailedToReadFile, FileConfigurationNotFound

class publicationFlow:

    def __init__(self, configKey, fileToBeProcessed, fileMetaDataKey, batchId):
        self.configKey = configKey
        self.fileToBeProcessed = fileToBeProcessed
        self.fileMetaDataKey = fileMetaDataKey
        self.batchId = batchId
        self.logger = logging.getLogger()
        self.logger.setLevel('INFO')

    def publicationProcessor(self):

        jobMetadataLogObj = jobMetadataLogger(self.fileMetaDataKey, self.batchId, self.fileToBeProcessed)
        jobMetadataLogObj.updateJobMetadata('started')

        #TODO configProvider from dynamodb
        ##dynamoConfigReaderObj = dynamoDbReader(self.fileMetaDataKey, self.batchId)
        ##configItem = dynamoConfigReaderObj.dynamoConfigReader()

        s3ConfigReaderObj = s3ConfigReader(self.configKey)
        configItem = s3ConfigReaderObj.s3ConfigReader()

        if configItem is not None:
            fileType = configItem.get('inputFormat')
            output = configItem.get('output')
            file = configItem.get('file')

            # Build dataframe for file
            readerObj = ReaderFactory.gets3reader(fileType, self.fileToBeProcessed, configItem)
            dfRead = readerObj.readFile()
            dfRead = readerObj.renameColumns()
            if file == 'AGED_SUSPENSE':
                agedSuspenseObj = transformColumns(configItem, dfRead)
                dfRead = agedSuspenseObj.valueTransformation()

            if not dfRead.empty:
                for outputItem in output:
                    writerObj = WriterFactory.writeToTarget(outputItem.get('outputWriter'), configItem, dfRead)
                    writerObj.writeDF()
            else:
                raise(FailedToReadFile(dict(fileName=self.fileMetaDataKey, stagingFilepath=self.fileToBeProcessed)))
        else:
            raise(FileConfigurationNotFound(dict(fileName=self.fileMetaDataKey, configKey=self.configKey)))
import boto3
import pandas as pd
import pyarrow.parquet as pq
import logging
import traceback
from com.aegonlife.publication.core.transformation.transformHandler import transformColumns


class s3Reader:

    def __init__(self, fileToBeProcessed, configItem):
        self.df = None
        self.fileToBeProcessed = fileToBeProcessed
        self.configItem = configItem
        self.s3 = boto3.resource('s3', region_name="ap-south-1")
        self.logger = logging.getLogger()
        self.logger.setLevel('INFO')
        self.inputBucket = self.configItem.get('inputBucket')
        self.uniqueKey = self.configItem.get('uniqueKey').split(',')
        self.stagingInputSchema = self.configItem.get('mapping').get('stagingInputSchema')
        self.inputfiledelimiter = self.configItem.get('delimiter')
        self.stagingInputSchema = self.configItem.get('mapping').get('stagingInputSchema')


class s3ParquetReader (s3Reader):
    def __init__(self, fileToBeProcessed, configItem):
        super().__init__(fileToBeProcessed, configItem)

    def readFile(self):
        try:
            fileToBeProcessed = 's3://' + self.inputBucket + '/' + self.fileToBeProcessed
            self.df = pq.read_table(fileToBeProcessed).to_pandas()
            #TODO not required to drop duplicates
            self.df = self.df.drop_duplicates(subset=self.uniqueKey, keep="last")

            if self.stagingInputSchema is not None:
                self.df.columns = self.stagingInputSchema.split(',')
            return self.df

        except Exception as e:
            self.logger.warning("Unable to write to s3 " + traceback.format_exc())

    def renameColumns(self):
        #entity_obj = getattr(importlib.import_module('.transformHandler', 'com.aegonlife.publication.core'), 'transformColumns')
        #print('entity_obj', entity_obj)
        transformColumnsObj = transformColumns(self.df, self.configItem)
        self.df = transformColumnsObj.renameColumns()
        return self.df

    def valueTransformation(self):
        self.transformColumnsObj = transformColumns(self.df, self.configItem)
        self.df = self.transformColumnsObj.valueTransformation()
        return self.df


class s3CsvReader(s3Reader):

    def __init__(self, fileToBeProcessed, configItem):
        super().__init__(fileToBeProcessed, configItem)

    def readFile(self):
        try:
            # reading S3 object
            obj = self.s3.Object(self.inputBucket, self.fileToBeProcessed)
            response_file = obj.get()['Body']._raw_stream
            self.df = pd.read_csv(response_file, sep=self.inputfiledelimiter, usecols=self.stagingInputSchema.split(','))
            return self.df

        except Exception as e:
            self.logger.warning("Unable to write to s3 " + traceback.format_exc())

    def renameColumns(self):
        transformColumnsObj = transformColumns(self.df, self.configItem)
        self.df = transformColumnsObj.renameColumns()
        return self.df

    def valueTransformation(self):
        self.transformColumnsObj = transformColumns(self.df, self.configItem)
        self.df = self.transformColumnsObj.valueTransformation()
        return self.df
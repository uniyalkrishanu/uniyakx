from com.aegonlife.publication.core.reader.s3Reader import *

class ReaderFactory:
    @staticmethod
    def gets3reader(filetype,fileToBeProcessed, configItem):
        if filetype == 'parquet':
            return s3ParquetReader(fileToBeProcessed, configItem)
        elif filetype == 'csv':
            return s3CsvReader(fileToBeProcessed, configItem)

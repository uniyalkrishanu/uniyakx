import boto3
import os
import json
from decimal import Decimal
from boto3.dynamodb.conditions import Key, Attr
from datetime import datetime


class jobMetadataLogger:

    def __init__(self, FileName, batchId, inputKey):
        self.FileName = FileName
        self.batchId = batchId
        self.inputKey = inputKey
        self.job_name = 'PROCESSOR_LAMBDA'
        self.dynamodb = boto3.resource('dynamodb')
        self.configTbl = self.dynamodb.Table(os.environ['FileMetadataLog'])  # aegone-datalake-file-master-dt

    def getJobMetadata(self, FileName, batchId):
        self.FileName = FileName
        self.batchId = batchId
        payload_JobMetadata = self.configTbl.query(KeyConditionExpression=Key('filename').eq(self.FileName),
                                              FilterExpression=Attr('batch_id').eq(self.batchId))
        return payload_JobMetadata['Items'][0]

    def updateJobMetadata(self, action):
        self.payload_JobMetadata = self.getJobMetadata(self.FileName, self.batchId)
        # To Check in Job Metadata is present
        if self.payload_JobMetadata is not None:
            if action == 'started':
                start_time = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f')
                # self.inputKey = self.payload_JobMetadata['inputKey']
                payload_JobDetails = {'job_name': self.job_name, 'start_time': start_time, 'status': 'STARTED', 'inputFileKey': self.inputKey, 'outputFileKey': 'NA'}
                # TO check status is logged once
                for JobDetails in self.payload_JobMetadata['job_details']:

                    if 'PROCESSOR_LAMBDA' not in JobDetails.values():
                        self.payload_JobMetadata['job_details'].append(payload_JobDetails)
                        self.payload_JobMetadata = json.loads(json.dumps(self.payload_JobMetadata), parse_float=Decimal)
                        response = self.configTbl.put_item(Item=self.payload_JobMetadata)
                        return response

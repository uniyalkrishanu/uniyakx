import boto3
import os
from boto3.dynamodb.conditions import Key, Attr
import json

class dynamoDbReader:

    def __init__(self, fileMetaDataKey, batchId):
        self.fileMetaDataKey = fileMetaDataKey
        self.batchId = batchId
        self.dynamodb = boto3.resource('dynamodb')
        self.configTbl = self.dynamodb.Table(os.environ['FileConfigTable'])  # aegone-datalake-ffa-file-config-dt

    def dynamoConfigReader(self):
        payload_JobMetadata = self.configTbl.query(KeyConditionExpression=Key('filename').eq(self.fileMetaDataKey),
                                              FilterExpression=Attr('batch_id').eq(self.batchId))
        return payload_JobMetadata


class s3ConfigReader:

    def __init__(self, configKey):
        self.configKey = configKey
        self.s3 = boto3.resource('s3')
        self.configbucket = os.environ['configbucket']

    def s3ConfigReader(self):
        print('self.configKey',self.configKey)
        for object in self.s3.Bucket(self.configbucket).objects.filter(Prefix=("config_publicationflow/" + self.configKey)):
            if self.configKey in object.key:
                self.configKey = object.key
                print('configKey', self.configKey)
                obj = self.s3.Object(self.configbucket, self.configKey)
                body = obj.get()['Body'].read().decode('utf-8')
                configFileItems = json.loads(body)
                return configFileItems
            else:
                print("config.json not available for {}".format(self.configKey))
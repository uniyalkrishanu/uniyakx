class transformColumns:

    def __init__(self, df, configItem):
        self.df = df
        self.configItem = configItem
        self.stagingOutputSchema = self.configItem.get('mapping').get('stagingOutputSchema')

    def renameColumns(self):
        if self.stagingOutputSchema is not None:
            self.df.columns = self.stagingOutputSchema.split(',')
        return self.df







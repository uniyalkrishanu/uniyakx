import psycopg2
import psycopg2.extras as extras
import os
import boto3
import logging
import traceback
import sys
from io import StringIO
from datetime import datetime
from dateutil.tz import gettz


class targetWriter:
    def __init__(self, configItem, df):
        self.s3 = boto3.resource('s3', region_name="ap-south-1")
        self.ssm = boto3.client('ssm')
        self.configItem = configItem
        self.df = df
        self.output = self.configItem.get('output')
        self.outputBucket = None  # self.configItem.get('outputBucket')
        self.outputPath = None  # self.configItem.get('outputPath')
        self.schema = None  # self.configItem.get('schema')
        self.table = None  # configItem.get('table')
        self.dbUniqueKey = None
        self.batch_metadata_params_namespace = os.environ['batch_metadata_params_namespace']
        self.conn = None
        self.cursor = None
        self.host = self.ssm.get_parameter(Name=self.batch_metadata_params_namespace + '.host')['Parameter']['Value']
        self.user = self.ssm.get_parameter(Name=self.batch_metadata_params_namespace + '.user')['Parameter']['Value']
        self.password = self.ssm.get_parameter(Name=self.batch_metadata_params_namespace + '.password')['Parameter']['Value']
        self.database = self.ssm.get_parameter(Name=self.batch_metadata_params_namespace + '.dbname')['Parameter']['Value']
        self.date_time = datetime.now().strftime("%Y%m%d%H%M%S")
        self.logger = logging.getLogger()
        self.logger.setLevel('INFO')


class s3CsvWriter(targetWriter):

    def __init__(self, configItem, df):
        super().__init__(configItem, df)

    def writeDF(self):
        df = self.writeCsv()
        return df

    def writeCsv(self):
        try:

            for outputItem in self.output:
                if 's3' in outputItem.get('outputWriter'):
                    # adding date for s3 key
                    self.outputBucket = outputItem.get('outputBucket')
                    self.outputPath = outputItem.get('outputPath') + self.date_time + ".csv"

            # writing json to s3
            csv_buffer = StringIO()
            self.df.to_csv(csv_buffer, index=False)
            response = self.s3.Object(self.outputBucket, self.outputPath).put(Body=csv_buffer.getvalue())
            return response
        except Exception as e:
            self.logger.warning("Unable to write to s3 " + traceback.format_exc())


class postgreWriter(targetWriter):

    def __init__(self, configItem, df):
        super().__init__(configItem, df)

    def writeDF(self):
        df = self.writePostgre()
        return df

    def getConnection(self):
        try:
            self.conn = psycopg2.connect("dbname={} user={} host={} password={}".format(self.database, self.user, self.host, self.password))
            return self.conn
        except:
            self.logger.error("Failed to get Connection:{}".format(sys.exc_info()[0]))
            self.logger.error(traceback.format_exc())

    def writePostgre(self):
        try:
            placeholder = ""
            result = {}

            self.conn = self.getConnection()
            # conn.autocommit = True
            self.cursor = self.conn.cursor()

            for outputItem in self.output:
                if 'postgre' in outputItem.get('outputWriter'):
                    self.schema = outputItem.get('schema')
                    self.table = self.schema + '.' + outputItem.get('table')
                    self.activeRecordUniqueKey = outputItem.get('activeRecordUniqueKey')
                    self.dbUniqueKey = outputItem.get('dbUniqueKey').split(',')

            # upsert logic for latest record for insertion Conflict
            for col in self.df.columns:
                placeholder = placeholder + "," + col + " = EXCLUDED." + col

            # To validate entries before insertion
            recordCount = self.getRecordCount()
            self.logger.info('Count before insertion in table {}, is {}'.format(self.table, recordCount))

            # update end_date for historical data
            curr_DateTime = str(datetime.now(tz=gettz('Asia/Kolkata')).strftime("%Y/%m/%d, %H:%M:%S")).replace(',','')
            tuple_updateCheck = [tuple(self.df[self.activeRecordUniqueKey])]
            update_query = "Update %s set end_date = '%s' where %s in %%s" % (self.table, curr_DateTime, self.activeRecordUniqueKey)
            results = extras.execute_values(self.cursor, update_query, tuple_updateCheck)
            self.conn.commit()

            # insert data in current process
            self.df['end_Date'] = ""
            tuples = [tuple(x) for x in self.df.to_numpy()]
            cols = ','.join(list(self.df.columns))
            dbUniqueKey = ', '.join(item for item in self.dbUniqueKey)
            query = "INSERT INTO %s(%s) VALUES %%s ON CONFLICT (%s) DO UPDATE SET %s" % (self.table, cols, dbUniqueKey, placeholder[1:])
            results = extras.execute_values(self.cursor, query, tuples)
            self.conn.commit()

            # To validate entries after insertion
            recordCount = self.getRecordCount()
            self.logger.info('Count after insertion in table {}, is {}'.format(self.table, recordCount))

            if self.cursor:
                self.cursor.close()
            if self.conn:
                self.conn.close()

            result["status"] = "success"
            return result
            # create_table = "CREATE TABLE finance_db.FFA_FINANCE_SUSPENSE_DAILY (suspense_account_type VARCHAR(255),cash_batch_id VARCHAR(255),payment_mode VARCHAR(255),applied_date VARCHAR(255),deposit_date VARCHAR(255),creation_date VARCHAR(255),name_of_customer VARCHAR(255),client_id VARCHAR(255),contract_no VARCHAR(255),modal_premium VARCHAR(255),amount VARCHAR(255),chq_dd_types VARCHAR(255),cheque_status VARCHAR(255),date_of_last_transaction_in_the_contract VARCHAR(255),no_of_days_pending VARCHAR(255),reason VARCHAR(255),branch_name VARCHAR(255),zone_name VARCHAR(255),next_modal_prem VARCHAR(255),billing_mode VARCHAR(255),paid_to_date VARCHAR(255),status VARCHAR(255),status_reason VARCHAR(255),batch_id VARCHAR(255),insert_timestamp  VARCHAR(255), end_date VARCHAR(255), suspense_account_type_new VARCHAR(255), reason_new VARCHAR(255), PRIMARY KEY(contract_no,suspense_account_type_new,reason_new))"
            # self.cursor.execute(create_table)
            # self.conn.commit()

        except:
            self.logger.warning("Failed to write data in PSql " + traceback.format_exc())
            self.cursor.close()
            self.conn.close()

    def getRecordCount(self):
        self.cursor.execute("select count(*) from %s" % self.table)
        results = self.cursor.fetchone()
        return str(results[0])
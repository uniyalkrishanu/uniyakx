from com.aegonlife.publication.core.writer.targetWriter import *
import logging

logger = logging.getLogger(__name__)
logger.setLevel('INFO')

class WriterFactory:
    @staticmethod
    def writeToTarget(outputWriter, configItem, df):
        
        if 's3' in outputWriter:
            return s3CsvWriter(configItem, df)
        elif 'postgre' in outputWriter:
            return postgreWriter(configItem, df)

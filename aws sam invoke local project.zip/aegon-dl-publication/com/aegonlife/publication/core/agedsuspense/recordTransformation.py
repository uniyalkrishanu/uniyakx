import pandas as pd
import numpy as np


class recordTransformation:
    def __init__(self, df, valueList):
        self.df = df
        self.valueList = valueList
        self.df_ToProcess = None
        self.df_UnProcessed = None
        self.df_replicated = None

    def calcAdvanceExcessPremiumAmount(self, amount, next_modal_prem):
        excessPremAmount = amount % next_modal_prem
        advancePremAmount = amount - excessPremAmount
        return [excessPremAmount, advancePremAmount]

    def getNewReasonandAmount(self, LineNo, excessPremAmount, advancePremAmount):
        reason_new = 'EXCESS PREMIUM' if LineNo == 1 else 'ADVANCE PREMIUM'
        amount = excessPremAmount if reason_new == 'EXCESS PREMIUM' else advancePremAmount
        return [reason_new, amount]

    def advance_prem_generator(self):
        for valueItemList in self.valueList:
            valueItemList = eval(valueItemList)
            self.df_ToProcess = self.df[(self.df['suspense_account_type'] == valueItemList[0]) & (self.df['reason'] == valueItemList[1])]
            self.df_UnProcessed = self.df[~self.df.index.isin(self.df_ToProcess.index)]

            # TODO remove custom filter for null amount
            self.df_ToProcess[['next_modal_prem', 'amount']].replace(np.nan, 0)
            self.df_ToProcess = self.df_ToProcess[(self.df_ToProcess['next_modal_prem'] > '0.0') & (self.df_ToProcess['amount'] > '0.0')]

            self.df_ToProcess[['next_modal_prem', 'amount']] = self.df_ToProcess[['next_modal_prem', 'amount']].astype(float)
            self.df_ToProcess[['excessPremAmount', 'advancePremAmount']] = self.df_ToProcess.apply(lambda row: self.calcAdvanceExcessPremiumAmount(row['amount'], row['next_modal_prem']), axis=1, result_type='expand')

            # replicating Lines for advance premium
            self.df_replicated = pd.DataFrame(np.repeat(self.df_ToProcess.values, 2, axis=0))
            self.df_replicated.columns = self.df_ToProcess.columns
            self.df_replicated['LineNo'] = self.df_replicated.groupby(['contract_no']).cumcount() + 1
            self.df_replicated[['reason_new', 'amount']] = self.df_replicated.apply(lambda row: self.getNewReasonandAmount(row['LineNo'], row['excessPremAmount'], row['advancePremAmount']), axis=1, result_type='expand')

            # Removing in-process attributes
            self.df_replicated = self.df_replicated.drop(['excessPremAmount', 'advancePremAmount', 'LineNo'], axis=1)
            self.df_replicated = self.df_replicated[self.df_replicated['amount'] > 0]

            self.df = pd.concat([self.df_UnProcessed, self.df_replicated])

        return self.df

    '''def advance_prem_generator(self, valueItemList, df_ToProcess):
        # TODO remove custom filter for null amount
        df_ToProcess[['modal_premium', 'amount']].replace(np.nan, 0)
        df_ToProcess = df_ToProcess[(df_ToProcess['modal_premium'] > '0') & (df_ToProcess['amount'] > '0')]

        df_ToProcess[['modal_premium', 'amount']] = df_ToProcess[['modal_premium', 'amount']].astype(float)
        df_ToProcess['advanceLine'] = (df_ToProcess['modal_premium'] / df_ToProcess['amount']).replace(np.nan, 0).apply(np.ceil)
        df_ToProcess['excessPremLine'] = df_ToProcess['modal_premium'] % df_ToProcess['amount']

        # TODO remove temp logic to limit duplicate line
        df_ToProcess['advanceLine'] = np.where((df_ToProcess['advanceLine'] <= 0) | (df_ToProcess['advanceLine'] > 3), 1, df_ToProcess['advanceLine'])

        # replicating Lines for advance premium
        df_replicated = pd.DataFrame(np.repeat(df_ToProcess.values, df_ToProcess['advanceLine'], axis=0))
        df_replicated.columns = df_ToProcess.columns
        df_replicated['LineNo'] = df_replicated.groupby(['contract_no']).cumcount() + 1
        df_replicated['reasonNew'] = np.where(df_replicated.LineNo == 1, 'EXCESS_PREMIUM', 'ADVANCE_PREMIUM')
        df_replicated['reason'] = df_replicated['reasonNew']
        # Updating amount for excess premium
        df_replicated['amount'] = np.where(df_replicated['reasonNew'] == 'EXCESS_PREMIUM', df_replicated['excessPremLine'], df_replicated['amount'])

        # Removing in-process attributes
        df_replicated = df_replicated.drop(['advanceLine', 'excessPremLine', 'LineNo', 'reasonNew'], axis=1)
        df_replicated = df_replicated[df_replicated['amount'] > 0]
        # print('df_replicated reason_generator', df_replicated.head(2))

        return df_replicated'''

    # self.df_ToProcess['excessPremAmount'] = self.df_ToProcess.apply(lambda row: self.calcExcessPremAmt(row['amount'], row['next_modal_prem']), axis=1)
    # self.df_ToProcess['advancePremAmount'] = self.df_ToProcess.apply(lambda row: self.calcAdvancePremAmt(row['amount'], row['excessPremAmount']), axis=1)

    '''self.df_replicated = pd.DataFrame(np.repeat(self.df_ToProcess.values, 2, axis=0))
    self.df_replicated.columns = self.df_ToProcess.columns
    self.df_replicated['LineNo'] = self.df_replicated.groupby(['contract_no']).cumcount() + 1
    self.df_replicated['reason_new'] = np.where(self.df_replicated.LineNo == 1, 'EXCESS PREMIUM', 'ADVANCE PREMIUM')
    self.df_replicated['amount'] = np.where(self.df_replicated['reason_new'] == 'EXCESS PREMIUM', self.df_replicated['excessPremAmount'], self.df_replicated['advancePremAmount'])'''
from com.aegonlife.publication.core.agedsuspense.recordTransformation import recordTransformation
from com.aegonlife.publication.core.agedsuspense.columnTransformation import columnTransformation

class transformColumns:

    def __init__(self, configItem, dfRead):
        self.df = dfRead
        self.configItem = configItem
        self.transformation = self.configItem.get('transformation')
        self.system = self.configItem.get('system')
        self.fileName = self.configItem.get('file')

    def valueTransformation(self):
        if self.transformation is not None:
            for transformationType in self.transformation:
                if 'columnTransformation' in transformationType:
                    self.df = self.columnTransformation(transformationType)
                if 'recordTransformation' in transformationType:
                    self.df = self.recordTransformation(transformationType)
        return self.df

    def columnTransformation(self, transformationType):

        for CT_item in transformationType['columnTransformation']:
            ruleName = CT_item.get('ruleName')
            columnToProcess = CT_item.get('columnName')
            inputColumnList = CT_item.get('inputList').split(',')

            # Original values required for multiple column transformation
            columnTransform = columnToProcess + '_new'
            self.df[columnTransform] = self.df[columnToProcess]

            columnTransformationObj = columnTransformation(self.df, self.system, self.fileName, columnToProcess, inputColumnList, columnTransform)
            if ruleName == 'suspense_type_lookup':
                self.df = columnTransformationObj.suspense_type_lookup()

        return self.df

    def recordTransformation(self, transformationType):

        for item in transformationType['recordTransformation']:
            ruleName = item.get('ruleName')
            valueList = item.get('valueList').split('|')

            recordTransformationObj = recordTransformation(self.df, valueList)
            if ruleName == 'advance_prem_generator':
                self.df = recordTransformationObj.advance_prem_generator()

        return self.df

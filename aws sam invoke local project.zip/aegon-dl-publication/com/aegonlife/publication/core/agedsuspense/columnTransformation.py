import numpy as np
import pandas as pd
from aegon_datalake_common.utils.look_up.reader.DynamoReader import DynamoReader

class columnTransformation:
    def __init__(self, df, system, fileName, columnToLookup, inputColumnList, columnTransform):
        self.df = df
        self.system = system
        self.fileName = fileName
        self.columnToLookup = columnToLookup
        self.inputColumnList = inputColumnList
        self.columnTransform = columnTransform

    def suspense_type_lookup(self):

        lookupReceivedList = []
        lookupValueSeries = self.df.groupby(self.inputColumnList).size()
        lookupValueList = list(map(list, [k for k, v in lookupValueSeries.iteritems()]))

        for lookupValueItem in lookupValueList:
            #newValue = self.getSuspenseLookupValue(self.system, self.columnToLookup, lookupValueItem)
            lookupReaderObj = DynamoReader(self.system, self.fileName, self.columnToLookup, lookupValueItem)
            newValue = lookupReaderObj.get_record()
            lookupReceivedDict = {'system': self.system, 'columnToLookup': self.columnToLookup, 'lookupValueItem': lookupValueItem, 'newValue': newValue}
            lookupReceivedList.append(lookupReceivedDict)
        lookupDf = pd.DataFrame(lookupReceivedList)

        for index, row in lookupDf.iterrows():
            self.df[self.columnTransform] = np.where((self.df[self.inputColumnList] == row['lookupValueItem']).all(axis=1), row['newValue'] if row['newValue'] is not None else self.df[self.columnTransform], self.df[self.columnTransform])
        # self.df[self.columnTransform] = self.df.apply(lambda row: self.getSuspenseValue(row[self.columnTransform], [row[self.inputColumnList[0]], row[self.inputColumnList[1]]]), axis=1)
        return self.df

    def getSuspenseLookupValue(self, system, columnToLookup, lookupValueItem):
        return_item = None
        callValues = {"items": [{"system": "FFA", "column": "suspense_account_type", "inputValueList": ['CWA Suspense', 'Cash With Application'], "output": "New Business Suspense"}, {"system": "FFA", "column": "suspense_account_type", "inputValueList": ['CWA Suspense', 'No CWA Due'], "output": "New Business Suspense"}, {"system": "FFA", "column": "suspense_account_type", "inputValueList": ['CWA Suspense', 'Transfer'], "output": "New Business Suspense"}, {"system": "FFA", "column": "suspense_account_type", "inputValueList": ['CWA Suspense', 'Underwriting to be Completed'], "output": "New Business Suspense"}, {"system": "FFA", "column": "reason", "inputValueList": ['CWA Suspense', 'Underwriting to be Completed'], "output": "Underwriting Pending"}, {"system": "FFA", "column": "suspense_account_type", "inputValueList": ['Company Suspense', 'Contract Unknown'], "output": "New Business Suspense"},
                                {"system": "FFA", "column": "reason", "inputValueList": ['Company Suspense', 'Contract Unknown'], "output": "Incomplete Proposal Form"}]}
        for item in callValues['items']:
            if system == item['system'] and columnToLookup == item['column'] and lookupValueItem == item['inputValueList']:
                return_item = item['output']
        return return_item